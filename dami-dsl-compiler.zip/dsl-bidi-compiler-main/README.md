# dsl-bidi-compiler

* Instalar antlr4. 
* Antes de nada, `npm install`.
* Compilar una gramática: `npm run compile grammars/nombreGramatica.g4`
* En `index.js` hay código de prueba para la gramática de BIDI. Se ejecuta con `node index.js`.

    ` node index.js tests/nombreScript.txt nombreOutput`

<!-- La estructura del proyecto y mucha ayuda está sacada de [aquí](https://github.com/alenakhineika/js-runtime) y de [este post](https://medium.com/dailyjs/compiler-in-javascript-using-antlr-9ec53fd2780f). -->
