// Generated from c:/Users/delfi/OneDrive - Universidade da Coru�a/LBD/Investigacion/DAMI-DSL/dsl-bidi-compiler-main/grammars/BIDIGrammar.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link BIDIGrammarParser}.
 */
public interface BIDIGrammarListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#parse}.
	 * @param ctx the parse tree
	 */
	void enterParse(BIDIGrammarParser.ParseContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#parse}.
	 * @param ctx the parse tree
	 */
	void exitParse(BIDIGrammarParser.ParseContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#sentence}.
	 * @param ctx the parse tree
	 */
	void enterSentence(BIDIGrammarParser.SentenceContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#sentence}.
	 * @param ctx the parse tree
	 */
	void exitSentence(BIDIGrammarParser.SentenceContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#alterStatement}.
	 * @param ctx the parse tree
	 */
	void enterAlterStatement(BIDIGrammarParser.AlterStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#alterStatement}.
	 * @param ctx the parse tree
	 */
	void exitAlterStatement(BIDIGrammarParser.AlterStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#createStatement}.
	 * @param ctx the parse tree
	 */
	void enterCreateStatement(BIDIGrammarParser.CreateStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#createStatement}.
	 * @param ctx the parse tree
	 */
	void exitCreateStatement(BIDIGrammarParser.CreateStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#dropStatement}.
	 * @param ctx the parse tree
	 */
	void enterDropStatement(BIDIGrammarParser.DropStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#dropStatement}.
	 * @param ctx the parse tree
	 */
	void exitDropStatement(BIDIGrammarParser.DropStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#generateScript}.
	 * @param ctx the parse tree
	 */
	void enterGenerateScript(BIDIGrammarParser.GenerateScriptContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#generateScript}.
	 * @param ctx the parse tree
	 */
	void exitGenerateScript(BIDIGrammarParser.GenerateScriptContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#insertStatement}.
	 * @param ctx the parse tree
	 */
	void enterInsertStatement(BIDIGrammarParser.InsertStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#insertStatement}.
	 * @param ctx the parse tree
	 */
	void exitInsertStatement(BIDIGrammarParser.InsertStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#valueStatement}.
	 * @param ctx the parse tree
	 */
	void enterValueStatement(BIDIGrammarParser.ValueStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#valueStatement}.
	 * @param ctx the parse tree
	 */
	void exitValueStatement(BIDIGrammarParser.ValueStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#mapStatement}.
	 * @param ctx the parse tree
	 */
	void enterMapStatement(BIDIGrammarParser.MapStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#mapStatement}.
	 * @param ctx the parse tree
	 */
	void exitMapStatement(BIDIGrammarParser.MapStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#mapAllStatement}.
	 * @param ctx the parse tree
	 */
	void enterMapAllStatement(BIDIGrammarParser.MapAllStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#mapAllStatement}.
	 * @param ctx the parse tree
	 */
	void exitMapAllStatement(BIDIGrammarParser.MapAllStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#mapSimpleStatement}.
	 * @param ctx the parse tree
	 */
	void enterMapSimpleStatement(BIDIGrammarParser.MapSimpleStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#mapSimpleStatement}.
	 * @param ctx the parse tree
	 */
	void exitMapSimpleStatement(BIDIGrammarParser.MapSimpleStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#columnMapping}.
	 * @param ctx the parse tree
	 */
	void enterColumnMapping(BIDIGrammarParser.ColumnMappingContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#columnMapping}.
	 * @param ctx the parse tree
	 */
	void exitColumnMapping(BIDIGrammarParser.ColumnMappingContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#sqlStatement}.
	 * @param ctx the parse tree
	 */
	void enterSqlStatement(BIDIGrammarParser.SqlStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#sqlStatement}.
	 * @param ctx the parse tree
	 */
	void exitSqlStatement(BIDIGrammarParser.SqlStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#saveRelation}.
	 * @param ctx the parse tree
	 */
	void enterSaveRelation(BIDIGrammarParser.SaveRelationContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#saveRelation}.
	 * @param ctx the parse tree
	 */
	void exitSaveRelation(BIDIGrammarParser.SaveRelationContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#keepingStatement}.
	 * @param ctx the parse tree
	 */
	void enterKeepingStatement(BIDIGrammarParser.KeepingStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#keepingStatement}.
	 * @param ctx the parse tree
	 */
	void exitKeepingStatement(BIDIGrammarParser.KeepingStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#foreignKeyStatement}.
	 * @param ctx the parse tree
	 */
	void enterForeignKeyStatement(BIDIGrammarParser.ForeignKeyStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#foreignKeyStatement}.
	 * @param ctx the parse tree
	 */
	void exitForeignKeyStatement(BIDIGrammarParser.ForeignKeyStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#foreignKeyRelation}.
	 * @param ctx the parse tree
	 */
	void enterForeignKeyRelation(BIDIGrammarParser.ForeignKeyRelationContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#foreignKeyRelation}.
	 * @param ctx the parse tree
	 */
	void exitForeignKeyRelation(BIDIGrammarParser.ForeignKeyRelationContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#getStatement}.
	 * @param ctx the parse tree
	 */
	void enterGetStatement(BIDIGrammarParser.GetStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#getStatement}.
	 * @param ctx the parse tree
	 */
	void exitGetStatement(BIDIGrammarParser.GetStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#attributeToTableStatement}.
	 * @param ctx the parse tree
	 */
	void enterAttributeToTableStatement(BIDIGrammarParser.AttributeToTableStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#attributeToTableStatement}.
	 * @param ctx the parse tree
	 */
	void exitAttributeToTableStatement(BIDIGrammarParser.AttributeToTableStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#updateStatement}.
	 * @param ctx the parse tree
	 */
	void enterUpdateStatement(BIDIGrammarParser.UpdateStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#updateStatement}.
	 * @param ctx the parse tree
	 */
	void exitUpdateStatement(BIDIGrammarParser.UpdateStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#setStatement}.
	 * @param ctx the parse tree
	 */
	void enterSetStatement(BIDIGrammarParser.SetStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#setStatement}.
	 * @param ctx the parse tree
	 */
	void exitSetStatement(BIDIGrammarParser.SetStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#foreignKeyUpdate}.
	 * @param ctx the parse tree
	 */
	void enterForeignKeyUpdate(BIDIGrammarParser.ForeignKeyUpdateContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#foreignKeyUpdate}.
	 * @param ctx the parse tree
	 */
	void exitForeignKeyUpdate(BIDIGrammarParser.ForeignKeyUpdateContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#addColumn}.
	 * @param ctx the parse tree
	 */
	void enterAddColumn(BIDIGrammarParser.AddColumnContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#addColumn}.
	 * @param ctx the parse tree
	 */
	void exitAddColumn(BIDIGrammarParser.AddColumnContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#addConstraint}.
	 * @param ctx the parse tree
	 */
	void enterAddConstraint(BIDIGrammarParser.AddConstraintContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#addConstraint}.
	 * @param ctx the parse tree
	 */
	void exitAddConstraint(BIDIGrammarParser.AddConstraintContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#addForeignKey}.
	 * @param ctx the parse tree
	 */
	void enterAddForeignKey(BIDIGrammarParser.AddForeignKeyContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#addForeignKey}.
	 * @param ctx the parse tree
	 */
	void exitAddForeignKey(BIDIGrammarParser.AddForeignKeyContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#createProduct}.
	 * @param ctx the parse tree
	 */
	void enterCreateProduct(BIDIGrammarParser.CreateProductContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#createProduct}.
	 * @param ctx the parse tree
	 */
	void exitCreateProduct(BIDIGrammarParser.CreateProductContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#createConnectionTo}.
	 * @param ctx the parse tree
	 */
	void enterCreateConnectionTo(BIDIGrammarParser.CreateConnectionToContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#createConnectionTo}.
	 * @param ctx the parse tree
	 */
	void exitCreateConnectionTo(BIDIGrammarParser.CreateConnectionToContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#createConnectionFrom}.
	 * @param ctx the parse tree
	 */
	void enterCreateConnectionFrom(BIDIGrammarParser.CreateConnectionFromContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#createConnectionFrom}.
	 * @param ctx the parse tree
	 */
	void exitCreateConnectionFrom(BIDIGrammarParser.CreateConnectionFromContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#connectionData}.
	 * @param ctx the parse tree
	 */
	void enterConnectionData(BIDIGrammarParser.ConnectionDataContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#connectionData}.
	 * @param ctx the parse tree
	 */
	void exitConnectionData(BIDIGrammarParser.ConnectionDataContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#createEntity}.
	 * @param ctx the parse tree
	 */
	void enterCreateEntity(BIDIGrammarParser.CreateEntityContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#createEntity}.
	 * @param ctx the parse tree
	 */
	void exitCreateEntity(BIDIGrammarParser.CreateEntityContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#createSchema}.
	 * @param ctx the parse tree
	 */
	void enterCreateSchema(BIDIGrammarParser.CreateSchemaContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#createSchema}.
	 * @param ctx the parse tree
	 */
	void exitCreateSchema(BIDIGrammarParser.CreateSchemaContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#dropColumn}.
	 * @param ctx the parse tree
	 */
	void enterDropColumn(BIDIGrammarParser.DropColumnContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#dropColumn}.
	 * @param ctx the parse tree
	 */
	void exitDropColumn(BIDIGrammarParser.DropColumnContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#dropConnection}.
	 * @param ctx the parse tree
	 */
	void enterDropConnection(BIDIGrammarParser.DropConnectionContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#dropConnection}.
	 * @param ctx the parse tree
	 */
	void exitDropConnection(BIDIGrammarParser.DropConnectionContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#dropSchema}.
	 * @param ctx the parse tree
	 */
	void enterDropSchema(BIDIGrammarParser.DropSchemaContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#dropSchema}.
	 * @param ctx the parse tree
	 */
	void exitDropSchema(BIDIGrammarParser.DropSchemaContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#dropTable}.
	 * @param ctx the parse tree
	 */
	void enterDropTable(BIDIGrammarParser.DropTableContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#dropTable}.
	 * @param ctx the parse tree
	 */
	void exitDropTable(BIDIGrammarParser.DropTableContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#selectStatement}.
	 * @param ctx the parse tree
	 */
	void enterSelectStatement(BIDIGrammarParser.SelectStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#selectStatement}.
	 * @param ctx the parse tree
	 */
	void exitSelectStatement(BIDIGrammarParser.SelectStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#column}.
	 * @param ctx the parse tree
	 */
	void enterColumn(BIDIGrammarParser.ColumnContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#column}.
	 * @param ctx the parse tree
	 */
	void exitColumn(BIDIGrammarParser.ColumnContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#value}.
	 * @param ctx the parse tree
	 */
	void enterValue(BIDIGrammarParser.ValueContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#value}.
	 * @param ctx the parse tree
	 */
	void exitValue(BIDIGrammarParser.ValueContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#property}.
	 * @param ctx the parse tree
	 */
	void enterProperty(BIDIGrammarParser.PropertyContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#property}.
	 * @param ctx the parse tree
	 */
	void exitProperty(BIDIGrammarParser.PropertyContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#propertyDefinition}.
	 * @param ctx the parse tree
	 */
	void enterPropertyDefinition(BIDIGrammarParser.PropertyDefinitionContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#propertyDefinition}.
	 * @param ctx the parse tree
	 */
	void exitPropertyDefinition(BIDIGrammarParser.PropertyDefinitionContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#relationshipDefinition}.
	 * @param ctx the parse tree
	 */
	void enterRelationshipDefinition(BIDIGrammarParser.RelationshipDefinitionContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#relationshipDefinition}.
	 * @param ctx the parse tree
	 */
	void exitRelationshipDefinition(BIDIGrammarParser.RelationshipDefinitionContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#mappedRelationshipDefinition}.
	 * @param ctx the parse tree
	 */
	void enterMappedRelationshipDefinition(BIDIGrammarParser.MappedRelationshipDefinitionContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#mappedRelationshipDefinition}.
	 * @param ctx the parse tree
	 */
	void exitMappedRelationshipDefinition(BIDIGrammarParser.MappedRelationshipDefinitionContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#ownedRelationshipDefinition}.
	 * @param ctx the parse tree
	 */
	void enterOwnedRelationshipDefinition(BIDIGrammarParser.OwnedRelationshipDefinitionContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#ownedRelationshipDefinition}.
	 * @param ctx the parse tree
	 */
	void exitOwnedRelationshipDefinition(BIDIGrammarParser.OwnedRelationshipDefinitionContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#cardinality}.
	 * @param ctx the parse tree
	 */
	void enterCardinality(BIDIGrammarParser.CardinalityContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#cardinality}.
	 * @param ctx the parse tree
	 */
	void exitCardinality(BIDIGrammarParser.CardinalityContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#srid}.
	 * @param ctx the parse tree
	 */
	void enterSrid(BIDIGrammarParser.SridContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#srid}.
	 * @param ctx the parse tree
	 */
	void exitSrid(BIDIGrammarParser.SridContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#identifier}.
	 * @param ctx the parse tree
	 */
	void enterIdentifier(BIDIGrammarParser.IdentifierContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#identifier}.
	 * @param ctx the parse tree
	 */
	void exitIdentifier(BIDIGrammarParser.IdentifierContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#host_identifier}.
	 * @param ctx the parse tree
	 */
	void enterHost_identifier(BIDIGrammarParser.Host_identifierContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#host_identifier}.
	 * @param ctx the parse tree
	 */
	void exitHost_identifier(BIDIGrammarParser.Host_identifierContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#password}.
	 * @param ctx the parse tree
	 */
	void enterPassword(BIDIGrammarParser.PasswordContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#password}.
	 * @param ctx the parse tree
	 */
	void exitPassword(BIDIGrammarParser.PasswordContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#text}.
	 * @param ctx the parse tree
	 */
	void enterText(BIDIGrammarParser.TextContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#text}.
	 * @param ctx the parse tree
	 */
	void exitText(BIDIGrammarParser.TextContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#hexColor}.
	 * @param ctx the parse tree
	 */
	void enterHexColor(BIDIGrammarParser.HexColorContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#hexColor}.
	 * @param ctx the parse tree
	 */
	void exitHexColor(BIDIGrammarParser.HexColorContext ctx);
	/**
	 * Enter a parse tree produced by {@link BIDIGrammarParser#floatNumber}.
	 * @param ctx the parse tree
	 */
	void enterFloatNumber(BIDIGrammarParser.FloatNumberContext ctx);
	/**
	 * Exit a parse tree produced by {@link BIDIGrammarParser#floatNumber}.
	 * @param ctx the parse tree
	 */
	void exitFloatNumber(BIDIGrammarParser.FloatNumberContext ctx);
}