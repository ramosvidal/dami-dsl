// Generated from c:/Users/delfi/OneDrive - Universidade da Coru�a/LBD/Investigacion/DAMI-DSL/dsl-bidi-compiler-main/grammars/BIDIGrammar.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue"})
public class BIDIGrammarParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.13.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		ADD_SYMBOL=1, ALL_SYMBOL=2, ALTER_SYMBOL=3, AND_SYMBOL=4, AS_SYMBOL=5, 
		ATTRIBUTE_SYMBOL=6, AUTHORIZATION_SYMBOL=7, BIDI_SYMBOL=8, BIDIRECTIONAL_SYMBOL=9, 
		CALL_SYMBOL=10, CASCADE_SYMBOL=11, CONNECTION_SYMBOL=12, CONSTRAINT_SYMBOL=13, 
		CREATE_SYMBOL=14, CURRENTUSER_SYMBOL=15, DATA_SYMBOL=16, DBNAME_SYMBOL=17, 
		DECOMPOSE_SYMBOL=18, DISPLAYSTRING_SYMBOL=19, DROP_SYMBOL=20, EDITABLE_SYMBOL=21, 
		ENTITY_SYMBOL=22, EQUALS_SYMBOL=23, EXECUTE_SYMBOL=24, EXISTS_SYMBOL=25, 
		EXTENSION_SYMBOL=26, FROM_SYMBOL=27, FOR_SYMBOL=28, FOREIGN_SYMBOL=29, 
		GENERATE_SYMBOL=30, GET_SYMBOL=31, HIDDEN_SYMBOL=32, HOST_SYMBOL=33, IDENTIFIER_SYMBOL=34, 
		IF_SYMBOL=35, IMPORT_SYMBOL=36, INSERT_SYMBOL=37, INTO_SYMBOL=38, KEEPING_SYMBOL=39, 
		KEY_SYMBOL=40, MAP_SYMBOL=41, MAPPEDBY_SYMBOL=42, MAPPING_SYMBOL=43, NEW_SYMBOL=44, 
		NOT_SYMBOL=45, NULL_SYMBOL=46, OPTIONS_SYMBOL=47, PASSWORD_SYMBOL=48, 
		PORT_SYMBOL=49, PRIMARY_SYMBOL=50, PROCEDURE_SYMBOL=51, PRODUCT_SYMBOL=52, 
		PROPERTIES_SYMBOL=53, REFERENCES_SYMBOL=54, RELATION_SYMBOL=55, RELATIONSHIP_SYMBOL=56, 
		REQUIRED_SYMBOL=57, SAVE_SYMBOL=58, SCHEMA_SYMBOL=59, SCRIPT_SYMBOL=60, 
		SELECT_SYMBOL=61, SERVER_SYMBOL=62, SET_SYMBOL=63, STYLE_SYMBOL=64, SQL_SYMBOL=65, 
		TABLE_SYMBOL=66, TO_SYMBOL=67, UNIQUE_SYMBOL=68, UPDATE_SYMBOL=69, URL_SYMBOL=70, 
		USE_SYMBOL=71, USER_SYMBOL=72, USING_SYMBOL=73, VALUES_SYMBOL=74, WHEN_SYMBOL=75, 
		WHERE_SYMBOL=76, WITH_SYMBOL=77, WRAPPER_SYMBOL=78, ZERO_ONE_SYMBOL=79, 
		ONE_ONE_SYMBOL=80, ZERO_MANY_SYMBOL=81, ONE_MANY_SYMBOL=82, TYPE=83, POUND_SYMBOL=84, 
		DOT_SYMBOL=85, OPAR_SYMBOL=86, CPAR_SYMBOL=87, COMMA_SYMBOL=88, SCOL_SYMBOL=89, 
		COL_SYMBOL=90, SQUOTE_SYMBOL=91, EQUAL_SYMBOL=92, HYPHEN_SYMBOL=93, HEX_COLOR=94, 
		INT_NUMBER=95, FLOAT_NUMBER=96, COMMENT=97, WHITESPACE=98, IDENTIFIER=99, 
		HOST_IDENTIFIER=100, STRING_LITERAL=101, QUOTED_TEXT=102;
	public static final int
		RULE_parse = 0, RULE_sentence = 1, RULE_alterStatement = 2, RULE_createStatement = 3, 
		RULE_dropStatement = 4, RULE_generateScript = 5, RULE_insertStatement = 6, 
		RULE_valueStatement = 7, RULE_mapStatement = 8, RULE_mapAllStatement = 9, 
		RULE_mapSimpleStatement = 10, RULE_columnMapping = 11, RULE_sqlStatement = 12, 
		RULE_saveRelation = 13, RULE_keepingStatement = 14, RULE_foreignKeyStatement = 15, 
		RULE_foreignKeyRelation = 16, RULE_getStatement = 17, RULE_attributeToTableStatement = 18, 
		RULE_updateStatement = 19, RULE_setStatement = 20, RULE_foreignKeyUpdate = 21, 
		RULE_addColumn = 22, RULE_addConstraint = 23, RULE_addForeignKey = 24, 
		RULE_createProduct = 25, RULE_createConnectionTo = 26, RULE_createConnectionFrom = 27, 
		RULE_connectionData = 28, RULE_createEntity = 29, RULE_createSchema = 30, 
		RULE_dropColumn = 31, RULE_dropConnection = 32, RULE_dropSchema = 33, 
		RULE_dropTable = 34, RULE_selectStatement = 35, RULE_column = 36, RULE_value = 37, 
		RULE_property = 38, RULE_propertyDefinition = 39, RULE_relationshipDefinition = 40, 
		RULE_mappedRelationshipDefinition = 41, RULE_ownedRelationshipDefinition = 42, 
		RULE_cardinality = 43, RULE_srid = 44, RULE_identifier = 45, RULE_host_identifier = 46, 
		RULE_password = 47, RULE_text = 48, RULE_hexColor = 49, RULE_floatNumber = 50;
	private static String[] makeRuleNames() {
		return new String[] {
			"parse", "sentence", "alterStatement", "createStatement", "dropStatement", 
			"generateScript", "insertStatement", "valueStatement", "mapStatement", 
			"mapAllStatement", "mapSimpleStatement", "columnMapping", "sqlStatement", 
			"saveRelation", "keepingStatement", "foreignKeyStatement", "foreignKeyRelation", 
			"getStatement", "attributeToTableStatement", "updateStatement", "setStatement", 
			"foreignKeyUpdate", "addColumn", "addConstraint", "addForeignKey", "createProduct", 
			"createConnectionTo", "createConnectionFrom", "connectionData", "createEntity", 
			"createSchema", "dropColumn", "dropConnection", "dropSchema", "dropTable", 
			"selectStatement", "column", "value", "property", "propertyDefinition", 
			"relationshipDefinition", "mappedRelationshipDefinition", "ownedRelationshipDefinition", 
			"cardinality", "srid", "identifier", "host_identifier", "password", "text", 
			"hexColor", "floatNumber"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, "'0..1'", "'1..1'", "'0..*'", 
			"'1..*'", null, "'#'", "'.'", "'('", "')'", "','", "';'", "':'", "'''", 
			"'='", "'-'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "ADD_SYMBOL", "ALL_SYMBOL", "ALTER_SYMBOL", "AND_SYMBOL", "AS_SYMBOL", 
			"ATTRIBUTE_SYMBOL", "AUTHORIZATION_SYMBOL", "BIDI_SYMBOL", "BIDIRECTIONAL_SYMBOL", 
			"CALL_SYMBOL", "CASCADE_SYMBOL", "CONNECTION_SYMBOL", "CONSTRAINT_SYMBOL", 
			"CREATE_SYMBOL", "CURRENTUSER_SYMBOL", "DATA_SYMBOL", "DBNAME_SYMBOL", 
			"DECOMPOSE_SYMBOL", "DISPLAYSTRING_SYMBOL", "DROP_SYMBOL", "EDITABLE_SYMBOL", 
			"ENTITY_SYMBOL", "EQUALS_SYMBOL", "EXECUTE_SYMBOL", "EXISTS_SYMBOL", 
			"EXTENSION_SYMBOL", "FROM_SYMBOL", "FOR_SYMBOL", "FOREIGN_SYMBOL", "GENERATE_SYMBOL", 
			"GET_SYMBOL", "HIDDEN_SYMBOL", "HOST_SYMBOL", "IDENTIFIER_SYMBOL", "IF_SYMBOL", 
			"IMPORT_SYMBOL", "INSERT_SYMBOL", "INTO_SYMBOL", "KEEPING_SYMBOL", "KEY_SYMBOL", 
			"MAP_SYMBOL", "MAPPEDBY_SYMBOL", "MAPPING_SYMBOL", "NEW_SYMBOL", "NOT_SYMBOL", 
			"NULL_SYMBOL", "OPTIONS_SYMBOL", "PASSWORD_SYMBOL", "PORT_SYMBOL", "PRIMARY_SYMBOL", 
			"PROCEDURE_SYMBOL", "PRODUCT_SYMBOL", "PROPERTIES_SYMBOL", "REFERENCES_SYMBOL", 
			"RELATION_SYMBOL", "RELATIONSHIP_SYMBOL", "REQUIRED_SYMBOL", "SAVE_SYMBOL", 
			"SCHEMA_SYMBOL", "SCRIPT_SYMBOL", "SELECT_SYMBOL", "SERVER_SYMBOL", "SET_SYMBOL", 
			"STYLE_SYMBOL", "SQL_SYMBOL", "TABLE_SYMBOL", "TO_SYMBOL", "UNIQUE_SYMBOL", 
			"UPDATE_SYMBOL", "URL_SYMBOL", "USE_SYMBOL", "USER_SYMBOL", "USING_SYMBOL", 
			"VALUES_SYMBOL", "WHEN_SYMBOL", "WHERE_SYMBOL", "WITH_SYMBOL", "WRAPPER_SYMBOL", 
			"ZERO_ONE_SYMBOL", "ONE_ONE_SYMBOL", "ZERO_MANY_SYMBOL", "ONE_MANY_SYMBOL", 
			"TYPE", "POUND_SYMBOL", "DOT_SYMBOL", "OPAR_SYMBOL", "CPAR_SYMBOL", "COMMA_SYMBOL", 
			"SCOL_SYMBOL", "COL_SYMBOL", "SQUOTE_SYMBOL", "EQUAL_SYMBOL", "HYPHEN_SYMBOL", 
			"HEX_COLOR", "INT_NUMBER", "FLOAT_NUMBER", "COMMENT", "WHITESPACE", "IDENTIFIER", 
			"HOST_IDENTIFIER", "STRING_LITERAL", "QUOTED_TEXT"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "BIDIGrammar.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public BIDIGrammarParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ParseContext extends ParserRuleContext {
		public List<SentenceContext> sentence() {
			return getRuleContexts(SentenceContext.class);
		}
		public SentenceContext sentence(int i) {
			return getRuleContext(SentenceContext.class,i);
		}
		public ParseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parse; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterParse(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitParse(this);
		}
	}

	public final ParseContext parse() throws RecognitionException {
		ParseContext _localctx = new ParseContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_parse);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(103); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(102);
				sentence();
				}
				}
				setState(105); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & 2337537015880L) != 0) || _la==UPDATE_SYMBOL );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SentenceContext extends ParserRuleContext {
		public AlterStatementContext alterStatement() {
			return getRuleContext(AlterStatementContext.class,0);
		}
		public AttributeToTableStatementContext attributeToTableStatement() {
			return getRuleContext(AttributeToTableStatementContext.class,0);
		}
		public CreateStatementContext createStatement() {
			return getRuleContext(CreateStatementContext.class,0);
		}
		public DropStatementContext dropStatement() {
			return getRuleContext(DropStatementContext.class,0);
		}
		public GenerateScriptContext generateScript() {
			return getRuleContext(GenerateScriptContext.class,0);
		}
		public MapStatementContext mapStatement() {
			return getRuleContext(MapStatementContext.class,0);
		}
		public InsertStatementContext insertStatement() {
			return getRuleContext(InsertStatementContext.class,0);
		}
		public UpdateStatementContext updateStatement() {
			return getRuleContext(UpdateStatementContext.class,0);
		}
		public SentenceContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sentence; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterSentence(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitSentence(this);
		}
	}

	public final SentenceContext sentence() throws RecognitionException {
		SentenceContext _localctx = new SentenceContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_sentence);
		try {
			setState(115);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ALTER_SYMBOL:
				enterOuterAlt(_localctx, 1);
				{
				setState(107);
				alterStatement();
				}
				break;
			case ATTRIBUTE_SYMBOL:
				enterOuterAlt(_localctx, 2);
				{
				setState(108);
				attributeToTableStatement();
				}
				break;
			case CREATE_SYMBOL:
				enterOuterAlt(_localctx, 3);
				{
				setState(109);
				createStatement();
				}
				break;
			case DROP_SYMBOL:
				enterOuterAlt(_localctx, 4);
				{
				setState(110);
				dropStatement();
				}
				break;
			case GENERATE_SYMBOL:
				enterOuterAlt(_localctx, 5);
				{
				setState(111);
				generateScript();
				}
				break;
			case MAP_SYMBOL:
				enterOuterAlt(_localctx, 6);
				{
				setState(112);
				mapStatement();
				}
				break;
			case INSERT_SYMBOL:
				enterOuterAlt(_localctx, 7);
				{
				setState(113);
				insertStatement();
				}
				break;
			case UPDATE_SYMBOL:
				enterOuterAlt(_localctx, 8);
				{
				setState(114);
				updateStatement();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AlterStatementContext extends ParserRuleContext {
		public TerminalNode ALTER_SYMBOL() { return getToken(BIDIGrammarParser.ALTER_SYMBOL, 0); }
		public TerminalNode TABLE_SYMBOL() { return getToken(BIDIGrammarParser.TABLE_SYMBOL, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public AddColumnContext addColumn() {
			return getRuleContext(AddColumnContext.class,0);
		}
		public AddConstraintContext addConstraint() {
			return getRuleContext(AddConstraintContext.class,0);
		}
		public AddForeignKeyContext addForeignKey() {
			return getRuleContext(AddForeignKeyContext.class,0);
		}
		public DropColumnContext dropColumn() {
			return getRuleContext(DropColumnContext.class,0);
		}
		public AlterStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_alterStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterAlterStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitAlterStatement(this);
		}
	}

	public final AlterStatementContext alterStatement() throws RecognitionException {
		AlterStatementContext _localctx = new AlterStatementContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_alterStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(117);
			match(ALTER_SYMBOL);
			setState(118);
			match(TABLE_SYMBOL);
			setState(119);
			identifier();
			setState(124);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,2,_ctx) ) {
			case 1:
				{
				setState(120);
				addColumn();
				}
				break;
			case 2:
				{
				setState(121);
				addConstraint();
				}
				break;
			case 3:
				{
				setState(122);
				addForeignKey();
				}
				break;
			case 4:
				{
				setState(123);
				dropColumn();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CreateStatementContext extends ParserRuleContext {
		public TerminalNode CREATE_SYMBOL() { return getToken(BIDIGrammarParser.CREATE_SYMBOL, 0); }
		public CreateProductContext createProduct() {
			return getRuleContext(CreateProductContext.class,0);
		}
		public CreateConnectionToContext createConnectionTo() {
			return getRuleContext(CreateConnectionToContext.class,0);
		}
		public CreateConnectionFromContext createConnectionFrom() {
			return getRuleContext(CreateConnectionFromContext.class,0);
		}
		public CreateEntityContext createEntity() {
			return getRuleContext(CreateEntityContext.class,0);
		}
		public CreateSchemaContext createSchema() {
			return getRuleContext(CreateSchemaContext.class,0);
		}
		public CreateStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_createStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterCreateStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitCreateStatement(this);
		}
	}

	public final CreateStatementContext createStatement() throws RecognitionException {
		CreateStatementContext _localctx = new CreateStatementContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_createStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(126);
			match(CREATE_SYMBOL);
			setState(132);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,3,_ctx) ) {
			case 1:
				{
				setState(127);
				createProduct();
				}
				break;
			case 2:
				{
				setState(128);
				createConnectionTo();
				}
				break;
			case 3:
				{
				setState(129);
				createConnectionFrom();
				}
				break;
			case 4:
				{
				setState(130);
				createEntity();
				}
				break;
			case 5:
				{
				setState(131);
				createSchema();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DropStatementContext extends ParserRuleContext {
		public TerminalNode DROP_SYMBOL() { return getToken(BIDIGrammarParser.DROP_SYMBOL, 0); }
		public DropConnectionContext dropConnection() {
			return getRuleContext(DropConnectionContext.class,0);
		}
		public DropSchemaContext dropSchema() {
			return getRuleContext(DropSchemaContext.class,0);
		}
		public DropTableContext dropTable() {
			return getRuleContext(DropTableContext.class,0);
		}
		public DropStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dropStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterDropStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitDropStatement(this);
		}
	}

	public final DropStatementContext dropStatement() throws RecognitionException {
		DropStatementContext _localctx = new DropStatementContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_dropStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(134);
			match(DROP_SYMBOL);
			setState(138);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CONNECTION_SYMBOL:
				{
				setState(135);
				dropConnection();
				}
				break;
			case SCHEMA_SYMBOL:
				{
				setState(136);
				dropSchema();
				}
				break;
			case TABLE_SYMBOL:
				{
				setState(137);
				dropTable();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GenerateScriptContext extends ParserRuleContext {
		public TerminalNode GENERATE_SYMBOL() { return getToken(BIDIGrammarParser.GENERATE_SYMBOL, 0); }
		public TerminalNode SCRIPT_SYMBOL() { return getToken(BIDIGrammarParser.SCRIPT_SYMBOL, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode SCOL_SYMBOL() { return getToken(BIDIGrammarParser.SCOL_SYMBOL, 0); }
		public GenerateScriptContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_generateScript; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterGenerateScript(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitGenerateScript(this);
		}
	}

	public final GenerateScriptContext generateScript() throws RecognitionException {
		GenerateScriptContext _localctx = new GenerateScriptContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_generateScript);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(140);
			match(GENERATE_SYMBOL);
			setState(141);
			match(SCRIPT_SYMBOL);
			setState(142);
			identifier();
			setState(143);
			match(SCOL_SYMBOL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class InsertStatementContext extends ParserRuleContext {
		public TerminalNode INSERT_SYMBOL() { return getToken(BIDIGrammarParser.INSERT_SYMBOL, 0); }
		public TerminalNode INTO_SYMBOL() { return getToken(BIDIGrammarParser.INTO_SYMBOL, 0); }
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public TerminalNode OPAR_SYMBOL() { return getToken(BIDIGrammarParser.OPAR_SYMBOL, 0); }
		public TerminalNode CPAR_SYMBOL() { return getToken(BIDIGrammarParser.CPAR_SYMBOL, 0); }
		public TerminalNode SCOL_SYMBOL() { return getToken(BIDIGrammarParser.SCOL_SYMBOL, 0); }
		public ValueStatementContext valueStatement() {
			return getRuleContext(ValueStatementContext.class,0);
		}
		public SelectStatementContext selectStatement() {
			return getRuleContext(SelectStatementContext.class,0);
		}
		public List<TerminalNode> COMMA_SYMBOL() { return getTokens(BIDIGrammarParser.COMMA_SYMBOL); }
		public TerminalNode COMMA_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.COMMA_SYMBOL, i);
		}
		public InsertStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_insertStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterInsertStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitInsertStatement(this);
		}
	}

	public final InsertStatementContext insertStatement() throws RecognitionException {
		InsertStatementContext _localctx = new InsertStatementContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_insertStatement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(145);
			match(INSERT_SYMBOL);
			setState(146);
			match(INTO_SYMBOL);
			setState(147);
			identifier();
			setState(148);
			match(OPAR_SYMBOL);
			setState(149);
			identifier();
			setState(154);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA_SYMBOL) {
				{
				{
				setState(150);
				match(COMMA_SYMBOL);
				setState(151);
				identifier();
				}
				}
				setState(156);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(157);
			match(CPAR_SYMBOL);
			setState(160);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case EQUAL_SYMBOL:
				{
				setState(158);
				valueStatement();
				}
				break;
			case SELECT_SYMBOL:
				{
				setState(159);
				selectStatement();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(162);
			match(SCOL_SYMBOL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ValueStatementContext extends ParserRuleContext {
		public TerminalNode EQUAL_SYMBOL() { return getToken(BIDIGrammarParser.EQUAL_SYMBOL, 0); }
		public List<ValueContext> value() {
			return getRuleContexts(ValueContext.class);
		}
		public ValueContext value(int i) {
			return getRuleContext(ValueContext.class,i);
		}
		public List<TerminalNode> COMMA_SYMBOL() { return getTokens(BIDIGrammarParser.COMMA_SYMBOL); }
		public TerminalNode COMMA_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.COMMA_SYMBOL, i);
		}
		public ValueStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_valueStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterValueStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitValueStatement(this);
		}
	}

	public final ValueStatementContext valueStatement() throws RecognitionException {
		ValueStatementContext _localctx = new ValueStatementContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_valueStatement);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(164);
			match(EQUAL_SYMBOL);
			setState(165);
			value();
			setState(170);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,7,_ctx);
			while ( _alt!=1 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1+1 ) {
					{
					{
					setState(166);
					match(COMMA_SYMBOL);
					setState(167);
					value();
					}
					} 
				}
				setState(172);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,7,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class MapStatementContext extends ParserRuleContext {
		public TerminalNode MAP_SYMBOL() { return getToken(BIDIGrammarParser.MAP_SYMBOL, 0); }
		public MapAllStatementContext mapAllStatement() {
			return getRuleContext(MapAllStatementContext.class,0);
		}
		public MapSimpleStatementContext mapSimpleStatement() {
			return getRuleContext(MapSimpleStatementContext.class,0);
		}
		public MapStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_mapStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterMapStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitMapStatement(this);
		}
	}

	public final MapStatementContext mapStatement() throws RecognitionException {
		MapStatementContext _localctx = new MapStatementContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_mapStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(173);
			match(MAP_SYMBOL);
			setState(176);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ALL_SYMBOL:
				{
				setState(174);
				mapAllStatement();
				}
				break;
			case IDENTIFIER:
				{
				setState(175);
				mapSimpleStatement();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class MapAllStatementContext extends ParserRuleContext {
		public TerminalNode ALL_SYMBOL() { return getToken(BIDIGrammarParser.ALL_SYMBOL, 0); }
		public TerminalNode PROPERTIES_SYMBOL() { return getToken(BIDIGrammarParser.PROPERTIES_SYMBOL, 0); }
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public TerminalNode TO_SYMBOL() { return getToken(BIDIGrammarParser.TO_SYMBOL, 0); }
		public TerminalNode SCOL_SYMBOL() { return getToken(BIDIGrammarParser.SCOL_SYMBOL, 0); }
		public TerminalNode OPAR_SYMBOL() { return getToken(BIDIGrammarParser.OPAR_SYMBOL, 0); }
		public List<ColumnMappingContext> columnMapping() {
			return getRuleContexts(ColumnMappingContext.class);
		}
		public ColumnMappingContext columnMapping(int i) {
			return getRuleContext(ColumnMappingContext.class,i);
		}
		public TerminalNode CPAR_SYMBOL() { return getToken(BIDIGrammarParser.CPAR_SYMBOL, 0); }
		public List<TerminalNode> COMMA_SYMBOL() { return getTokens(BIDIGrammarParser.COMMA_SYMBOL); }
		public TerminalNode COMMA_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.COMMA_SYMBOL, i);
		}
		public List<ForeignKeyRelationContext> foreignKeyRelation() {
			return getRuleContexts(ForeignKeyRelationContext.class);
		}
		public ForeignKeyRelationContext foreignKeyRelation(int i) {
			return getRuleContext(ForeignKeyRelationContext.class,i);
		}
		public GetStatementContext getStatement() {
			return getRuleContext(GetStatementContext.class,0);
		}
		public List<SaveRelationContext> saveRelation() {
			return getRuleContexts(SaveRelationContext.class);
		}
		public SaveRelationContext saveRelation(int i) {
			return getRuleContext(SaveRelationContext.class,i);
		}
		public MapAllStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_mapAllStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterMapAllStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitMapAllStatement(this);
		}
	}

	public final MapAllStatementContext mapAllStatement() throws RecognitionException {
		MapAllStatementContext _localctx = new MapAllStatementContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_mapAllStatement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(178);
			match(ALL_SYMBOL);
			setState(179);
			match(PROPERTIES_SYMBOL);
			setState(180);
			identifier();
			setState(181);
			match(TO_SYMBOL);
			setState(182);
			identifier();
			setState(209);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==OPAR_SYMBOL) {
				{
				setState(183);
				match(OPAR_SYMBOL);
				setState(184);
				columnMapping();
				setState(192);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA_SYMBOL) {
					{
					{
					setState(185);
					match(COMMA_SYMBOL);
					setState(188);
					_errHandler.sync(this);
					switch (_input.LA(1)) {
					case NULL_SYMBOL:
					case SQL_SYMBOL:
					case IDENTIFIER:
						{
						setState(186);
						columnMapping();
						}
						break;
					case SAVE_SYMBOL:
						{
						setState(187);
						saveRelation();
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					}
					}
					setState(194);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(195);
				match(CPAR_SYMBOL);
				setState(204);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==FOREIGN_SYMBOL) {
					{
					setState(196);
					foreignKeyRelation();
					setState(201);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==COMMA_SYMBOL) {
						{
						{
						setState(197);
						match(COMMA_SYMBOL);
						setState(198);
						foreignKeyRelation();
						}
						}
						setState(203);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					}
				}

				setState(207);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==GET_SYMBOL) {
					{
					setState(206);
					getStatement();
					}
				}

				}
			}

			setState(211);
			match(SCOL_SYMBOL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class MapSimpleStatementContext extends ParserRuleContext {
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public TerminalNode TO_SYMBOL() { return getToken(BIDIGrammarParser.TO_SYMBOL, 0); }
		public List<TerminalNode> OPAR_SYMBOL() { return getTokens(BIDIGrammarParser.OPAR_SYMBOL); }
		public TerminalNode OPAR_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.OPAR_SYMBOL, i);
		}
		public List<ColumnMappingContext> columnMapping() {
			return getRuleContexts(ColumnMappingContext.class);
		}
		public ColumnMappingContext columnMapping(int i) {
			return getRuleContext(ColumnMappingContext.class,i);
		}
		public List<TerminalNode> CPAR_SYMBOL() { return getTokens(BIDIGrammarParser.CPAR_SYMBOL); }
		public TerminalNode CPAR_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.CPAR_SYMBOL, i);
		}
		public TerminalNode SCOL_SYMBOL() { return getToken(BIDIGrammarParser.SCOL_SYMBOL, 0); }
		public List<TerminalNode> COMMA_SYMBOL() { return getTokens(BIDIGrammarParser.COMMA_SYMBOL); }
		public TerminalNode COMMA_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.COMMA_SYMBOL, i);
		}
		public TerminalNode WHERE_SYMBOL() { return getToken(BIDIGrammarParser.WHERE_SYMBOL, 0); }
		public List<TerminalNode> EQUAL_SYMBOL() { return getTokens(BIDIGrammarParser.EQUAL_SYMBOL); }
		public TerminalNode EQUAL_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.EQUAL_SYMBOL, i);
		}
		public List<ForeignKeyRelationContext> foreignKeyRelation() {
			return getRuleContexts(ForeignKeyRelationContext.class);
		}
		public ForeignKeyRelationContext foreignKeyRelation(int i) {
			return getRuleContext(ForeignKeyRelationContext.class,i);
		}
		public GetStatementContext getStatement() {
			return getRuleContext(GetStatementContext.class,0);
		}
		public List<SaveRelationContext> saveRelation() {
			return getRuleContexts(SaveRelationContext.class);
		}
		public SaveRelationContext saveRelation(int i) {
			return getRuleContext(SaveRelationContext.class,i);
		}
		public List<TerminalNode> AND_SYMBOL() { return getTokens(BIDIGrammarParser.AND_SYMBOL); }
		public TerminalNode AND_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.AND_SYMBOL, i);
		}
		public MapSimpleStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_mapSimpleStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterMapSimpleStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitMapSimpleStatement(this);
		}
	}

	public final MapSimpleStatementContext mapSimpleStatement() throws RecognitionException {
		MapSimpleStatementContext _localctx = new MapSimpleStatementContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_mapSimpleStatement);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(213);
			identifier();
			setState(218);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,15,_ctx);
			while ( _alt!=1 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1+1 ) {
					{
					{
					setState(214);
					match(COMMA_SYMBOL);
					setState(215);
					identifier();
					}
					} 
				}
				setState(220);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,15,_ctx);
			}
			setState(221);
			match(TO_SYMBOL);
			setState(222);
			identifier();
			setState(223);
			match(OPAR_SYMBOL);
			setState(224);
			columnMapping();
			setState(232);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA_SYMBOL) {
				{
				{
				setState(225);
				match(COMMA_SYMBOL);
				setState(228);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case NULL_SYMBOL:
				case SQL_SYMBOL:
				case IDENTIFIER:
					{
					setState(226);
					columnMapping();
					}
					break;
				case SAVE_SYMBOL:
					{
					setState(227);
					saveRelation();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				}
				setState(234);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(235);
			match(CPAR_SYMBOL);
			setState(253);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==WHERE_SYMBOL) {
				{
				setState(236);
				match(WHERE_SYMBOL);
				setState(237);
				match(OPAR_SYMBOL);
				setState(238);
				identifier();
				setState(239);
				match(EQUAL_SYMBOL);
				setState(240);
				identifier();
				setState(248);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,18,_ctx);
				while ( _alt!=1 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1+1 ) {
						{
						{
						setState(241);
						match(AND_SYMBOL);
						setState(242);
						identifier();
						setState(243);
						match(EQUAL_SYMBOL);
						setState(244);
						identifier();
						}
						} 
					}
					setState(250);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,18,_ctx);
				}
				setState(251);
				match(CPAR_SYMBOL);
				}
			}

			setState(263);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==FOREIGN_SYMBOL) {
				{
				setState(255);
				foreignKeyRelation();
				setState(260);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA_SYMBOL) {
					{
					{
					setState(256);
					match(COMMA_SYMBOL);
					setState(257);
					foreignKeyRelation();
					}
					}
					setState(262);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
			}

			setState(266);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==GET_SYMBOL) {
				{
				setState(265);
				getStatement();
				}
			}

			setState(268);
			match(SCOL_SYMBOL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ColumnMappingContext extends ParserRuleContext {
		public TerminalNode TO_SYMBOL() { return getToken(BIDIGrammarParser.TO_SYMBOL, 0); }
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public TerminalNode NULL_SYMBOL() { return getToken(BIDIGrammarParser.NULL_SYMBOL, 0); }
		public SqlStatementContext sqlStatement() {
			return getRuleContext(SqlStatementContext.class,0);
		}
		public TerminalNode TYPE() { return getToken(BIDIGrammarParser.TYPE, 0); }
		public ForeignKeyStatementContext foreignKeyStatement() {
			return getRuleContext(ForeignKeyStatementContext.class,0);
		}
		public ColumnMappingContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_columnMapping; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterColumnMapping(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitColumnMapping(this);
		}
	}

	public final ColumnMappingContext columnMapping() throws RecognitionException {
		ColumnMappingContext _localctx = new ColumnMappingContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_columnMapping);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(273);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case IDENTIFIER:
				{
				setState(270);
				identifier();
				}
				break;
			case NULL_SYMBOL:
				{
				setState(271);
				match(NULL_SYMBOL);
				}
				break;
			case SQL_SYMBOL:
				{
				setState(272);
				sqlStatement();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(276);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==TYPE) {
				{
				setState(275);
				match(TYPE);
				}
			}

			setState(278);
			match(TO_SYMBOL);
			setState(279);
			identifier();
			setState(281);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==FOREIGN_SYMBOL) {
				{
				setState(280);
				foreignKeyStatement();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SqlStatementContext extends ParserRuleContext {
		public TerminalNode SQL_SYMBOL() { return getToken(BIDIGrammarParser.SQL_SYMBOL, 0); }
		public TerminalNode COL_SYMBOL() { return getToken(BIDIGrammarParser.COL_SYMBOL, 0); }
		public TerminalNode QUOTED_TEXT() { return getToken(BIDIGrammarParser.QUOTED_TEXT, 0); }
		public SqlStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sqlStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterSqlStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitSqlStatement(this);
		}
	}

	public final SqlStatementContext sqlStatement() throws RecognitionException {
		SqlStatementContext _localctx = new SqlStatementContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_sqlStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(283);
			match(SQL_SYMBOL);
			setState(284);
			match(COL_SYMBOL);
			setState(285);
			match(QUOTED_TEXT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SaveRelationContext extends ParserRuleContext {
		public TerminalNode SAVE_SYMBOL() { return getToken(BIDIGrammarParser.SAVE_SYMBOL, 0); }
		public TerminalNode RELATION_SYMBOL() { return getToken(BIDIGrammarParser.RELATION_SYMBOL, 0); }
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public List<TerminalNode> DOT_SYMBOL() { return getTokens(BIDIGrammarParser.DOT_SYMBOL); }
		public TerminalNode DOT_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.DOT_SYMBOL, i);
		}
		public TerminalNode AS_SYMBOL() { return getToken(BIDIGrammarParser.AS_SYMBOL, 0); }
		public List<TerminalNode> TYPE() { return getTokens(BIDIGrammarParser.TYPE); }
		public TerminalNode TYPE(int i) {
			return getToken(BIDIGrammarParser.TYPE, i);
		}
		public TerminalNode EQUALS_SYMBOL() { return getToken(BIDIGrammarParser.EQUALS_SYMBOL, 0); }
		public SaveRelationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_saveRelation; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterSaveRelation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitSaveRelation(this);
		}
	}

	public final SaveRelationContext saveRelation() throws RecognitionException {
		SaveRelationContext _localctx = new SaveRelationContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_saveRelation);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(287);
			match(SAVE_SYMBOL);
			setState(288);
			match(RELATION_SYMBOL);
			setState(289);
			identifier();
			setState(290);
			match(DOT_SYMBOL);
			setState(291);
			identifier();
			setState(292);
			match(AS_SYMBOL);
			setState(293);
			identifier();
			setState(294);
			match(TYPE);
			{
			setState(295);
			match(EQUALS_SYMBOL);
			setState(296);
			identifier();
			setState(297);
			match(DOT_SYMBOL);
			setState(298);
			identifier();
			setState(299);
			match(TYPE);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class KeepingStatementContext extends ParserRuleContext {
		public TerminalNode KEEPING_SYMBOL() { return getToken(BIDIGrammarParser.KEEPING_SYMBOL, 0); }
		public TerminalNode OPAR_SYMBOL() { return getToken(BIDIGrammarParser.OPAR_SYMBOL, 0); }
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public List<TerminalNode> DOT_SYMBOL() { return getTokens(BIDIGrammarParser.DOT_SYMBOL); }
		public TerminalNode DOT_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.DOT_SYMBOL, i);
		}
		public List<TerminalNode> TYPE() { return getTokens(BIDIGrammarParser.TYPE); }
		public TerminalNode TYPE(int i) {
			return getToken(BIDIGrammarParser.TYPE, i);
		}
		public TerminalNode EQUAL_SYMBOL() { return getToken(BIDIGrammarParser.EQUAL_SYMBOL, 0); }
		public TerminalNode CPAR_SYMBOL() { return getToken(BIDIGrammarParser.CPAR_SYMBOL, 0); }
		public KeepingStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_keepingStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterKeepingStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitKeepingStatement(this);
		}
	}

	public final KeepingStatementContext keepingStatement() throws RecognitionException {
		KeepingStatementContext _localctx = new KeepingStatementContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_keepingStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(301);
			match(KEEPING_SYMBOL);
			setState(302);
			match(OPAR_SYMBOL);
			setState(303);
			identifier();
			setState(304);
			match(DOT_SYMBOL);
			setState(305);
			identifier();
			setState(306);
			match(TYPE);
			setState(307);
			match(EQUAL_SYMBOL);
			setState(308);
			identifier();
			setState(309);
			match(DOT_SYMBOL);
			setState(310);
			identifier();
			setState(311);
			match(TYPE);
			setState(312);
			match(CPAR_SYMBOL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ForeignKeyStatementContext extends ParserRuleContext {
		public TerminalNode FOREIGN_SYMBOL() { return getToken(BIDIGrammarParser.FOREIGN_SYMBOL, 0); }
		public TerminalNode KEY_SYMBOL() { return getToken(BIDIGrammarParser.KEY_SYMBOL, 0); }
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public TerminalNode OPAR_SYMBOL() { return getToken(BIDIGrammarParser.OPAR_SYMBOL, 0); }
		public TerminalNode CPAR_SYMBOL() { return getToken(BIDIGrammarParser.CPAR_SYMBOL, 0); }
		public ForeignKeyStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_foreignKeyStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterForeignKeyStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitForeignKeyStatement(this);
		}
	}

	public final ForeignKeyStatementContext foreignKeyStatement() throws RecognitionException {
		ForeignKeyStatementContext _localctx = new ForeignKeyStatementContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_foreignKeyStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(314);
			match(FOREIGN_SYMBOL);
			setState(315);
			match(KEY_SYMBOL);
			setState(316);
			identifier();
			setState(317);
			match(OPAR_SYMBOL);
			setState(318);
			identifier();
			setState(319);
			match(CPAR_SYMBOL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ForeignKeyRelationContext extends ParserRuleContext {
		public TerminalNode FOREIGN_SYMBOL() { return getToken(BIDIGrammarParser.FOREIGN_SYMBOL, 0); }
		public TerminalNode KEY_SYMBOL() { return getToken(BIDIGrammarParser.KEY_SYMBOL, 0); }
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public List<TerminalNode> DOT_SYMBOL() { return getTokens(BIDIGrammarParser.DOT_SYMBOL); }
		public TerminalNode DOT_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.DOT_SYMBOL, i);
		}
		public TerminalNode REFERENCES_SYMBOL() { return getToken(BIDIGrammarParser.REFERENCES_SYMBOL, 0); }
		public ForeignKeyRelationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_foreignKeyRelation; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterForeignKeyRelation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitForeignKeyRelation(this);
		}
	}

	public final ForeignKeyRelationContext foreignKeyRelation() throws RecognitionException {
		ForeignKeyRelationContext _localctx = new ForeignKeyRelationContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_foreignKeyRelation);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(321);
			match(FOREIGN_SYMBOL);
			setState(322);
			match(KEY_SYMBOL);
			setState(323);
			identifier();
			setState(324);
			match(DOT_SYMBOL);
			setState(325);
			identifier();
			setState(326);
			match(REFERENCES_SYMBOL);
			setState(327);
			identifier();
			setState(328);
			match(DOT_SYMBOL);
			setState(329);
			identifier();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GetStatementContext extends ParserRuleContext {
		public TerminalNode GET_SYMBOL() { return getToken(BIDIGrammarParser.GET_SYMBOL, 0); }
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public TerminalNode FROM_SYMBOL() { return getToken(BIDIGrammarParser.FROM_SYMBOL, 0); }
		public TerminalNode DOT_SYMBOL() { return getToken(BIDIGrammarParser.DOT_SYMBOL, 0); }
		public TerminalNode WHEN_SYMBOL() { return getToken(BIDIGrammarParser.WHEN_SYMBOL, 0); }
		public TerminalNode EQUAL_SYMBOL() { return getToken(BIDIGrammarParser.EQUAL_SYMBOL, 0); }
		public GetStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_getStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterGetStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitGetStatement(this);
		}
	}

	public final GetStatementContext getStatement() throws RecognitionException {
		GetStatementContext _localctx = new GetStatementContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_getStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(331);
			match(GET_SYMBOL);
			setState(332);
			identifier();
			setState(333);
			match(FROM_SYMBOL);
			setState(334);
			identifier();
			setState(335);
			match(DOT_SYMBOL);
			setState(336);
			identifier();
			setState(337);
			match(WHEN_SYMBOL);
			setState(338);
			identifier();
			setState(339);
			match(EQUAL_SYMBOL);
			setState(340);
			identifier();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AttributeToTableStatementContext extends ParserRuleContext {
		public TerminalNode ATTRIBUTE_SYMBOL() { return getToken(BIDIGrammarParser.ATTRIBUTE_SYMBOL, 0); }
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public List<TerminalNode> OPAR_SYMBOL() { return getTokens(BIDIGrammarParser.OPAR_SYMBOL); }
		public TerminalNode OPAR_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.OPAR_SYMBOL, i);
		}
		public List<TerminalNode> CPAR_SYMBOL() { return getTokens(BIDIGrammarParser.CPAR_SYMBOL); }
		public TerminalNode CPAR_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.CPAR_SYMBOL, i);
		}
		public TerminalNode TO_SYMBOL() { return getToken(BIDIGrammarParser.TO_SYMBOL, 0); }
		public TerminalNode TABLE_SYMBOL() { return getToken(BIDIGrammarParser.TABLE_SYMBOL, 0); }
		public List<ColumnMappingContext> columnMapping() {
			return getRuleContexts(ColumnMappingContext.class);
		}
		public ColumnMappingContext columnMapping(int i) {
			return getRuleContext(ColumnMappingContext.class,i);
		}
		public ForeignKeyRelationContext foreignKeyRelation() {
			return getRuleContext(ForeignKeyRelationContext.class,0);
		}
		public TerminalNode SCOL_SYMBOL() { return getToken(BIDIGrammarParser.SCOL_SYMBOL, 0); }
		public List<TerminalNode> COMMA_SYMBOL() { return getTokens(BIDIGrammarParser.COMMA_SYMBOL); }
		public TerminalNode COMMA_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.COMMA_SYMBOL, i);
		}
		public List<SaveRelationContext> saveRelation() {
			return getRuleContexts(SaveRelationContext.class);
		}
		public SaveRelationContext saveRelation(int i) {
			return getRuleContext(SaveRelationContext.class,i);
		}
		public AttributeToTableStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_attributeToTableStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterAttributeToTableStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitAttributeToTableStatement(this);
		}
	}

	public final AttributeToTableStatementContext attributeToTableStatement() throws RecognitionException {
		AttributeToTableStatementContext _localctx = new AttributeToTableStatementContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_attributeToTableStatement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(342);
			match(ATTRIBUTE_SYMBOL);
			setState(343);
			identifier();
			setState(344);
			match(OPAR_SYMBOL);
			setState(345);
			identifier();
			setState(346);
			match(CPAR_SYMBOL);
			setState(347);
			match(TO_SYMBOL);
			setState(348);
			match(TABLE_SYMBOL);
			setState(349);
			identifier();
			setState(350);
			match(OPAR_SYMBOL);
			setState(351);
			columnMapping();
			setState(359);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA_SYMBOL) {
				{
				{
				setState(352);
				match(COMMA_SYMBOL);
				setState(355);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case NULL_SYMBOL:
				case SQL_SYMBOL:
				case IDENTIFIER:
					{
					setState(353);
					columnMapping();
					}
					break;
				case SAVE_SYMBOL:
					{
					setState(354);
					saveRelation();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				}
				setState(361);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(362);
			match(CPAR_SYMBOL);
			setState(363);
			foreignKeyRelation();
			setState(364);
			match(SCOL_SYMBOL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class UpdateStatementContext extends ParserRuleContext {
		public TerminalNode UPDATE_SYMBOL() { return getToken(BIDIGrammarParser.UPDATE_SYMBOL, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode SCOL_SYMBOL() { return getToken(BIDIGrammarParser.SCOL_SYMBOL, 0); }
		public SetStatementContext setStatement() {
			return getRuleContext(SetStatementContext.class,0);
		}
		public ForeignKeyUpdateContext foreignKeyUpdate() {
			return getRuleContext(ForeignKeyUpdateContext.class,0);
		}
		public UpdateStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_updateStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterUpdateStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitUpdateStatement(this);
		}
	}

	public final UpdateStatementContext updateStatement() throws RecognitionException {
		UpdateStatementContext _localctx = new UpdateStatementContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_updateStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(366);
			match(UPDATE_SYMBOL);
			setState(367);
			identifier();
			setState(370);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SET_SYMBOL:
				{
				setState(368);
				setStatement();
				}
				break;
			case FOREIGN_SYMBOL:
				{
				setState(369);
				foreignKeyUpdate();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(372);
			match(SCOL_SYMBOL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SetStatementContext extends ParserRuleContext {
		public TerminalNode SET_SYMBOL() { return getToken(BIDIGrammarParser.SET_SYMBOL, 0); }
		public ColumnContext column() {
			return getRuleContext(ColumnContext.class,0);
		}
		public List<TerminalNode> EQUAL_SYMBOL() { return getTokens(BIDIGrammarParser.EQUAL_SYMBOL); }
		public TerminalNode EQUAL_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.EQUAL_SYMBOL, i);
		}
		public TerminalNode OPAR_SYMBOL() { return getToken(BIDIGrammarParser.OPAR_SYMBOL, 0); }
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public TerminalNode FROM_SYMBOL() { return getToken(BIDIGrammarParser.FROM_SYMBOL, 0); }
		public TerminalNode CPAR_SYMBOL() { return getToken(BIDIGrammarParser.CPAR_SYMBOL, 0); }
		public List<TerminalNode> COMMA_SYMBOL() { return getTokens(BIDIGrammarParser.COMMA_SYMBOL); }
		public TerminalNode COMMA_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.COMMA_SYMBOL, i);
		}
		public List<TerminalNode> DOT_SYMBOL() { return getTokens(BIDIGrammarParser.DOT_SYMBOL); }
		public TerminalNode DOT_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.DOT_SYMBOL, i);
		}
		public TerminalNode IDENTIFIER() { return getToken(BIDIGrammarParser.IDENTIFIER, 0); }
		public TerminalNode WHERE_SYMBOL() { return getToken(BIDIGrammarParser.WHERE_SYMBOL, 0); }
		public SetStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_setStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterSetStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitSetStatement(this);
		}
	}

	public final SetStatementContext setStatement() throws RecognitionException {
		SetStatementContext _localctx = new SetStatementContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_setStatement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(374);
			match(SET_SYMBOL);
			setState(375);
			column();
			setState(376);
			match(EQUAL_SYMBOL);
			setState(377);
			match(OPAR_SYMBOL);
			setState(378);
			identifier();
			setState(383);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA_SYMBOL) {
				{
				{
				setState(379);
				match(COMMA_SYMBOL);
				setState(380);
				identifier();
				}
				}
				setState(385);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(386);
			match(FROM_SYMBOL);
			setState(387);
			identifier();
			setState(397);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==DOT_SYMBOL) {
				{
				setState(388);
				match(DOT_SYMBOL);
				setState(389);
				identifier();
				setState(390);
				match(EQUAL_SYMBOL);
				setState(391);
				identifier();
				setState(392);
				match(DOT_SYMBOL);
				setState(393);
				identifier();
				setState(394);
				match(DOT_SYMBOL);
				setState(395);
				match(IDENTIFIER);
				}
			}

			setState(406);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==WHERE_SYMBOL) {
				{
				setState(399);
				match(WHERE_SYMBOL);
				setState(400);
				identifier();
				setState(401);
				match(EQUAL_SYMBOL);
				setState(402);
				identifier();
				setState(403);
				match(DOT_SYMBOL);
				setState(404);
				identifier();
				}
			}

			setState(408);
			match(CPAR_SYMBOL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ForeignKeyUpdateContext extends ParserRuleContext {
		public TerminalNode FOREIGN_SYMBOL() { return getToken(BIDIGrammarParser.FOREIGN_SYMBOL, 0); }
		public TerminalNode KEY_SYMBOL() { return getToken(BIDIGrammarParser.KEY_SYMBOL, 0); }
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public TerminalNode REFERENCES_SYMBOL() { return getToken(BIDIGrammarParser.REFERENCES_SYMBOL, 0); }
		public TerminalNode OPAR_SYMBOL() { return getToken(BIDIGrammarParser.OPAR_SYMBOL, 0); }
		public TerminalNode CPAR_SYMBOL() { return getToken(BIDIGrammarParser.CPAR_SYMBOL, 0); }
		public ForeignKeyUpdateContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_foreignKeyUpdate; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterForeignKeyUpdate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitForeignKeyUpdate(this);
		}
	}

	public final ForeignKeyUpdateContext foreignKeyUpdate() throws RecognitionException {
		ForeignKeyUpdateContext _localctx = new ForeignKeyUpdateContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_foreignKeyUpdate);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(410);
			match(FOREIGN_SYMBOL);
			setState(411);
			match(KEY_SYMBOL);
			setState(412);
			identifier();
			setState(413);
			match(REFERENCES_SYMBOL);
			setState(414);
			identifier();
			setState(415);
			match(OPAR_SYMBOL);
			setState(416);
			identifier();
			setState(417);
			match(CPAR_SYMBOL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AddColumnContext extends ParserRuleContext {
		public TerminalNode ADD_SYMBOL() { return getToken(BIDIGrammarParser.ADD_SYMBOL, 0); }
		public PropertyContext property() {
			return getRuleContext(PropertyContext.class,0);
		}
		public TerminalNode SCOL_SYMBOL() { return getToken(BIDIGrammarParser.SCOL_SYMBOL, 0); }
		public AddColumnContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_addColumn; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterAddColumn(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitAddColumn(this);
		}
	}

	public final AddColumnContext addColumn() throws RecognitionException {
		AddColumnContext _localctx = new AddColumnContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_addColumn);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(419);
			match(ADD_SYMBOL);
			setState(420);
			property();
			setState(421);
			match(SCOL_SYMBOL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AddConstraintContext extends ParserRuleContext {
		public TerminalNode ADD_SYMBOL() { return getToken(BIDIGrammarParser.ADD_SYMBOL, 0); }
		public TerminalNode CONSTRAINT_SYMBOL() { return getToken(BIDIGrammarParser.CONSTRAINT_SYMBOL, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public AddConstraintContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_addConstraint; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterAddConstraint(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitAddConstraint(this);
		}
	}

	public final AddConstraintContext addConstraint() throws RecognitionException {
		AddConstraintContext _localctx = new AddConstraintContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_addConstraint);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(423);
			match(ADD_SYMBOL);
			setState(424);
			match(CONSTRAINT_SYMBOL);
			setState(425);
			identifier();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AddForeignKeyContext extends ParserRuleContext {
		public TerminalNode ADD_SYMBOL() { return getToken(BIDIGrammarParser.ADD_SYMBOL, 0); }
		public TerminalNode FOREIGN_SYMBOL() { return getToken(BIDIGrammarParser.FOREIGN_SYMBOL, 0); }
		public TerminalNode KEY_SYMBOL() { return getToken(BIDIGrammarParser.KEY_SYMBOL, 0); }
		public TerminalNode OPAR_SYMBOL() { return getToken(BIDIGrammarParser.OPAR_SYMBOL, 0); }
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public TerminalNode CPAR_SYMBOL() { return getToken(BIDIGrammarParser.CPAR_SYMBOL, 0); }
		public TerminalNode REFERENCES_SYMBOL() { return getToken(BIDIGrammarParser.REFERENCES_SYMBOL, 0); }
		public TerminalNode SCOL_SYMBOL() { return getToken(BIDIGrammarParser.SCOL_SYMBOL, 0); }
		public AddForeignKeyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_addForeignKey; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterAddForeignKey(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitAddForeignKey(this);
		}
	}

	public final AddForeignKeyContext addForeignKey() throws RecognitionException {
		AddForeignKeyContext _localctx = new AddForeignKeyContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_addForeignKey);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(427);
			match(ADD_SYMBOL);
			setState(428);
			match(FOREIGN_SYMBOL);
			setState(429);
			match(KEY_SYMBOL);
			setState(430);
			match(OPAR_SYMBOL);
			setState(431);
			identifier();
			setState(432);
			match(CPAR_SYMBOL);
			setState(433);
			match(REFERENCES_SYMBOL);
			setState(434);
			identifier();
			setState(435);
			match(SCOL_SYMBOL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CreateProductContext extends ParserRuleContext {
		public TerminalNode PRODUCT_SYMBOL() { return getToken(BIDIGrammarParser.PRODUCT_SYMBOL, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode SCOL_SYMBOL() { return getToken(BIDIGrammarParser.SCOL_SYMBOL, 0); }
		public CreateProductContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_createProduct; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterCreateProduct(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitCreateProduct(this);
		}
	}

	public final CreateProductContext createProduct() throws RecognitionException {
		CreateProductContext _localctx = new CreateProductContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_createProduct);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(437);
			match(PRODUCT_SYMBOL);
			setState(438);
			identifier();
			setState(439);
			match(SCOL_SYMBOL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CreateConnectionToContext extends ParserRuleContext {
		public TerminalNode CONNECTION_SYMBOL() { return getToken(BIDIGrammarParser.CONNECTION_SYMBOL, 0); }
		public TerminalNode TO_SYMBOL() { return getToken(BIDIGrammarParser.TO_SYMBOL, 0); }
		public ConnectionDataContext connectionData() {
			return getRuleContext(ConnectionDataContext.class,0);
		}
		public TerminalNode SCOL_SYMBOL() { return getToken(BIDIGrammarParser.SCOL_SYMBOL, 0); }
		public CreateConnectionToContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_createConnectionTo; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterCreateConnectionTo(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitCreateConnectionTo(this);
		}
	}

	public final CreateConnectionToContext createConnectionTo() throws RecognitionException {
		CreateConnectionToContext _localctx = new CreateConnectionToContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_createConnectionTo);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(441);
			match(CONNECTION_SYMBOL);
			setState(442);
			match(TO_SYMBOL);
			setState(443);
			connectionData();
			setState(444);
			match(SCOL_SYMBOL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CreateConnectionFromContext extends ParserRuleContext {
		public TerminalNode CONNECTION_SYMBOL() { return getToken(BIDIGrammarParser.CONNECTION_SYMBOL, 0); }
		public TerminalNode FROM_SYMBOL() { return getToken(BIDIGrammarParser.FROM_SYMBOL, 0); }
		public ConnectionDataContext connectionData() {
			return getRuleContext(ConnectionDataContext.class,0);
		}
		public TerminalNode SCOL_SYMBOL() { return getToken(BIDIGrammarParser.SCOL_SYMBOL, 0); }
		public CreateConnectionFromContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_createConnectionFrom; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterCreateConnectionFrom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitCreateConnectionFrom(this);
		}
	}

	public final CreateConnectionFromContext createConnectionFrom() throws RecognitionException {
		CreateConnectionFromContext _localctx = new CreateConnectionFromContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_createConnectionFrom);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(446);
			match(CONNECTION_SYMBOL);
			setState(447);
			match(FROM_SYMBOL);
			setState(448);
			connectionData();
			setState(449);
			match(SCOL_SYMBOL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ConnectionDataContext extends ParserRuleContext {
		public TerminalNode OPAR_SYMBOL() { return getToken(BIDIGrammarParser.OPAR_SYMBOL, 0); }
		public TerminalNode DBNAME_SYMBOL() { return getToken(BIDIGrammarParser.DBNAME_SYMBOL, 0); }
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public List<TerminalNode> COMMA_SYMBOL() { return getTokens(BIDIGrammarParser.COMMA_SYMBOL); }
		public TerminalNode COMMA_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.COMMA_SYMBOL, i);
		}
		public TerminalNode HOST_SYMBOL() { return getToken(BIDIGrammarParser.HOST_SYMBOL, 0); }
		public TerminalNode PORT_SYMBOL() { return getToken(BIDIGrammarParser.PORT_SYMBOL, 0); }
		public TerminalNode INT_NUMBER() { return getToken(BIDIGrammarParser.INT_NUMBER, 0); }
		public TerminalNode USER_SYMBOL() { return getToken(BIDIGrammarParser.USER_SYMBOL, 0); }
		public TerminalNode PASSWORD_SYMBOL() { return getToken(BIDIGrammarParser.PASSWORD_SYMBOL, 0); }
		public TerminalNode SCHEMA_SYMBOL() { return getToken(BIDIGrammarParser.SCHEMA_SYMBOL, 0); }
		public TerminalNode CPAR_SYMBOL() { return getToken(BIDIGrammarParser.CPAR_SYMBOL, 0); }
		public ConnectionDataContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_connectionData; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterConnectionData(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitConnectionData(this);
		}
	}

	public final ConnectionDataContext connectionData() throws RecognitionException {
		ConnectionDataContext _localctx = new ConnectionDataContext(_ctx, getState());
		enterRule(_localctx, 56, RULE_connectionData);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(451);
			match(OPAR_SYMBOL);
			setState(452);
			match(DBNAME_SYMBOL);
			setState(453);
			identifier();
			setState(454);
			match(COMMA_SYMBOL);
			setState(455);
			match(HOST_SYMBOL);
			setState(456);
			identifier();
			setState(457);
			match(COMMA_SYMBOL);
			setState(458);
			match(PORT_SYMBOL);
			setState(459);
			match(INT_NUMBER);
			setState(460);
			match(COMMA_SYMBOL);
			setState(461);
			match(USER_SYMBOL);
			setState(462);
			identifier();
			setState(463);
			match(COMMA_SYMBOL);
			setState(464);
			match(PASSWORD_SYMBOL);
			setState(465);
			identifier();
			setState(466);
			match(COMMA_SYMBOL);
			setState(467);
			match(SCHEMA_SYMBOL);
			setState(468);
			identifier();
			setState(469);
			match(CPAR_SYMBOL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CreateEntityContext extends ParserRuleContext {
		public TerminalNode ENTITY_SYMBOL() { return getToken(BIDIGrammarParser.ENTITY_SYMBOL, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode OPAR_SYMBOL() { return getToken(BIDIGrammarParser.OPAR_SYMBOL, 0); }
		public List<PropertyContext> property() {
			return getRuleContexts(PropertyContext.class);
		}
		public PropertyContext property(int i) {
			return getRuleContext(PropertyContext.class,i);
		}
		public TerminalNode CPAR_SYMBOL() { return getToken(BIDIGrammarParser.CPAR_SYMBOL, 0); }
		public TerminalNode SCOL_SYMBOL() { return getToken(BIDIGrammarParser.SCOL_SYMBOL, 0); }
		public List<TerminalNode> COMMA_SYMBOL() { return getTokens(BIDIGrammarParser.COMMA_SYMBOL); }
		public TerminalNode COMMA_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.COMMA_SYMBOL, i);
		}
		public CreateEntityContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_createEntity; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterCreateEntity(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitCreateEntity(this);
		}
	}

	public final CreateEntityContext createEntity() throws RecognitionException {
		CreateEntityContext _localctx = new CreateEntityContext(_ctx, getState());
		enterRule(_localctx, 58, RULE_createEntity);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(471);
			match(ENTITY_SYMBOL);
			setState(472);
			identifier();
			setState(473);
			match(OPAR_SYMBOL);
			setState(474);
			property();
			setState(479);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA_SYMBOL) {
				{
				{
				setState(475);
				match(COMMA_SYMBOL);
				setState(476);
				property();
				}
				}
				setState(481);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(482);
			match(CPAR_SYMBOL);
			setState(483);
			match(SCOL_SYMBOL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CreateSchemaContext extends ParserRuleContext {
		public TerminalNode SCHEMA_SYMBOL() { return getToken(BIDIGrammarParser.SCHEMA_SYMBOL, 0); }
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public TerminalNode SCOL_SYMBOL() { return getToken(BIDIGrammarParser.SCOL_SYMBOL, 0); }
		public TerminalNode AUTHORIZATION_SYMBOL() { return getToken(BIDIGrammarParser.AUTHORIZATION_SYMBOL, 0); }
		public CreateSchemaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_createSchema; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterCreateSchema(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitCreateSchema(this);
		}
	}

	public final CreateSchemaContext createSchema() throws RecognitionException {
		CreateSchemaContext _localctx = new CreateSchemaContext(_ctx, getState());
		enterRule(_localctx, 60, RULE_createSchema);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(485);
			match(SCHEMA_SYMBOL);
			setState(486);
			identifier();
			setState(489);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==AUTHORIZATION_SYMBOL) {
				{
				setState(487);
				match(AUTHORIZATION_SYMBOL);
				setState(488);
				identifier();
				}
			}

			setState(491);
			match(SCOL_SYMBOL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DropColumnContext extends ParserRuleContext {
		public TerminalNode DROP_SYMBOL() { return getToken(BIDIGrammarParser.DROP_SYMBOL, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode SCOL_SYMBOL() { return getToken(BIDIGrammarParser.SCOL_SYMBOL, 0); }
		public DropColumnContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dropColumn; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterDropColumn(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitDropColumn(this);
		}
	}

	public final DropColumnContext dropColumn() throws RecognitionException {
		DropColumnContext _localctx = new DropColumnContext(_ctx, getState());
		enterRule(_localctx, 62, RULE_dropColumn);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(493);
			match(DROP_SYMBOL);
			setState(494);
			identifier();
			setState(495);
			match(SCOL_SYMBOL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DropConnectionContext extends ParserRuleContext {
		public TerminalNode CONNECTION_SYMBOL() { return getToken(BIDIGrammarParser.CONNECTION_SYMBOL, 0); }
		public TerminalNode SCOL_SYMBOL() { return getToken(BIDIGrammarParser.SCOL_SYMBOL, 0); }
		public DropConnectionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dropConnection; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterDropConnection(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitDropConnection(this);
		}
	}

	public final DropConnectionContext dropConnection() throws RecognitionException {
		DropConnectionContext _localctx = new DropConnectionContext(_ctx, getState());
		enterRule(_localctx, 64, RULE_dropConnection);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(497);
			match(CONNECTION_SYMBOL);
			setState(498);
			match(SCOL_SYMBOL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DropSchemaContext extends ParserRuleContext {
		public TerminalNode SCHEMA_SYMBOL() { return getToken(BIDIGrammarParser.SCHEMA_SYMBOL, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode SCOL_SYMBOL() { return getToken(BIDIGrammarParser.SCOL_SYMBOL, 0); }
		public DropSchemaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dropSchema; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterDropSchema(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitDropSchema(this);
		}
	}

	public final DropSchemaContext dropSchema() throws RecognitionException {
		DropSchemaContext _localctx = new DropSchemaContext(_ctx, getState());
		enterRule(_localctx, 66, RULE_dropSchema);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(500);
			match(SCHEMA_SYMBOL);
			setState(501);
			identifier();
			setState(502);
			match(SCOL_SYMBOL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DropTableContext extends ParserRuleContext {
		public TerminalNode TABLE_SYMBOL() { return getToken(BIDIGrammarParser.TABLE_SYMBOL, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode SCOL_SYMBOL() { return getToken(BIDIGrammarParser.SCOL_SYMBOL, 0); }
		public DropTableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dropTable; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterDropTable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitDropTable(this);
		}
	}

	public final DropTableContext dropTable() throws RecognitionException {
		DropTableContext _localctx = new DropTableContext(_ctx, getState());
		enterRule(_localctx, 68, RULE_dropTable);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(504);
			match(TABLE_SYMBOL);
			setState(505);
			identifier();
			setState(506);
			match(SCOL_SYMBOL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SelectStatementContext extends ParserRuleContext {
		public TerminalNode SELECT_SYMBOL() { return getToken(BIDIGrammarParser.SELECT_SYMBOL, 0); }
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public TerminalNode FROM_SYMBOL() { return getToken(BIDIGrammarParser.FROM_SYMBOL, 0); }
		public List<TerminalNode> COMMA_SYMBOL() { return getTokens(BIDIGrammarParser.COMMA_SYMBOL); }
		public TerminalNode COMMA_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.COMMA_SYMBOL, i);
		}
		public List<TerminalNode> DOT_SYMBOL() { return getTokens(BIDIGrammarParser.DOT_SYMBOL); }
		public TerminalNode DOT_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.DOT_SYMBOL, i);
		}
		public List<TerminalNode> EQUAL_SYMBOL() { return getTokens(BIDIGrammarParser.EQUAL_SYMBOL); }
		public TerminalNode EQUAL_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.EQUAL_SYMBOL, i);
		}
		public TerminalNode IDENTIFIER() { return getToken(BIDIGrammarParser.IDENTIFIER, 0); }
		public TerminalNode WHERE_SYMBOL() { return getToken(BIDIGrammarParser.WHERE_SYMBOL, 0); }
		public SelectStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_selectStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterSelectStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitSelectStatement(this);
		}
	}

	public final SelectStatementContext selectStatement() throws RecognitionException {
		SelectStatementContext _localctx = new SelectStatementContext(_ctx, getState());
		enterRule(_localctx, 70, RULE_selectStatement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(508);
			match(SELECT_SYMBOL);
			setState(509);
			identifier();
			setState(514);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA_SYMBOL) {
				{
				{
				setState(510);
				match(COMMA_SYMBOL);
				setState(511);
				identifier();
				}
				}
				setState(516);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(517);
			match(FROM_SYMBOL);
			setState(518);
			identifier();
			setState(528);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==DOT_SYMBOL) {
				{
				setState(519);
				match(DOT_SYMBOL);
				setState(520);
				identifier();
				setState(521);
				match(EQUAL_SYMBOL);
				setState(522);
				identifier();
				setState(523);
				match(DOT_SYMBOL);
				setState(524);
				identifier();
				setState(525);
				match(DOT_SYMBOL);
				setState(526);
				match(IDENTIFIER);
				}
			}

			setState(537);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==WHERE_SYMBOL) {
				{
				setState(530);
				match(WHERE_SYMBOL);
				setState(531);
				identifier();
				setState(532);
				match(EQUAL_SYMBOL);
				setState(533);
				identifier();
				setState(534);
				match(DOT_SYMBOL);
				setState(535);
				identifier();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ColumnContext extends ParserRuleContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public ColumnContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_column; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterColumn(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitColumn(this);
		}
	}

	public final ColumnContext column() throws RecognitionException {
		ColumnContext _localctx = new ColumnContext(_ctx, getState());
		enterRule(_localctx, 72, RULE_column);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(539);
			identifier();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ValueContext extends ParserRuleContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public ValueContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_value; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterValue(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitValue(this);
		}
	}

	public final ValueContext value() throws RecognitionException {
		ValueContext _localctx = new ValueContext(_ctx, getState());
		enterRule(_localctx, 74, RULE_value);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(541);
			identifier();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PropertyContext extends ParserRuleContext {
		public PropertyDefinitionContext propertyDefinition() {
			return getRuleContext(PropertyDefinitionContext.class,0);
		}
		public RelationshipDefinitionContext relationshipDefinition() {
			return getRuleContext(RelationshipDefinitionContext.class,0);
		}
		public PropertyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_property; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterProperty(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitProperty(this);
		}
	}

	public final PropertyContext property() throws RecognitionException {
		PropertyContext _localctx = new PropertyContext(_ctx, getState());
		enterRule(_localctx, 76, RULE_property);
		try {
			setState(545);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,37,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(543);
				propertyDefinition();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(544);
				relationshipDefinition();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PropertyDefinitionContext extends ParserRuleContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode TYPE() { return getToken(BIDIGrammarParser.TYPE, 0); }
		public List<TerminalNode> IDENTIFIER_SYMBOL() { return getTokens(BIDIGrammarParser.IDENTIFIER_SYMBOL); }
		public TerminalNode IDENTIFIER_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.IDENTIFIER_SYMBOL, i);
		}
		public List<TerminalNode> DISPLAYSTRING_SYMBOL() { return getTokens(BIDIGrammarParser.DISPLAYSTRING_SYMBOL); }
		public TerminalNode DISPLAYSTRING_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.DISPLAYSTRING_SYMBOL, i);
		}
		public List<TerminalNode> REQUIRED_SYMBOL() { return getTokens(BIDIGrammarParser.REQUIRED_SYMBOL); }
		public TerminalNode REQUIRED_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.REQUIRED_SYMBOL, i);
		}
		public List<TerminalNode> UNIQUE_SYMBOL() { return getTokens(BIDIGrammarParser.UNIQUE_SYMBOL); }
		public TerminalNode UNIQUE_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.UNIQUE_SYMBOL, i);
		}
		public List<TerminalNode> NOT_SYMBOL() { return getTokens(BIDIGrammarParser.NOT_SYMBOL); }
		public TerminalNode NOT_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.NOT_SYMBOL, i);
		}
		public List<TerminalNode> NULL_SYMBOL() { return getTokens(BIDIGrammarParser.NULL_SYMBOL); }
		public TerminalNode NULL_SYMBOL(int i) {
			return getToken(BIDIGrammarParser.NULL_SYMBOL, i);
		}
		public PropertyDefinitionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_propertyDefinition; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterPropertyDefinition(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitPropertyDefinition(this);
		}
	}

	public final PropertyDefinitionContext propertyDefinition() throws RecognitionException {
		PropertyDefinitionContext _localctx = new PropertyDefinitionContext(_ctx, getState());
		enterRule(_localctx, 78, RULE_propertyDefinition);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(547);
			identifier();
			setState(548);
			match(TYPE);
			setState(557);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((((_la - 19)) & ~0x3f) == 0 && ((1L << (_la - 19)) & 563224898469889L) != 0)) {
				{
				setState(555);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case IDENTIFIER_SYMBOL:
					{
					setState(549);
					match(IDENTIFIER_SYMBOL);
					}
					break;
				case DISPLAYSTRING_SYMBOL:
					{
					setState(550);
					match(DISPLAYSTRING_SYMBOL);
					}
					break;
				case REQUIRED_SYMBOL:
					{
					setState(551);
					match(REQUIRED_SYMBOL);
					}
					break;
				case UNIQUE_SYMBOL:
					{
					setState(552);
					match(UNIQUE_SYMBOL);
					}
					break;
				case NOT_SYMBOL:
					{
					setState(553);
					match(NOT_SYMBOL);
					setState(554);
					match(NULL_SYMBOL);
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				setState(559);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class RelationshipDefinitionContext extends ParserRuleContext {
		public OwnedRelationshipDefinitionContext ownedRelationshipDefinition() {
			return getRuleContext(OwnedRelationshipDefinitionContext.class,0);
		}
		public MappedRelationshipDefinitionContext mappedRelationshipDefinition() {
			return getRuleContext(MappedRelationshipDefinitionContext.class,0);
		}
		public RelationshipDefinitionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_relationshipDefinition; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterRelationshipDefinition(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitRelationshipDefinition(this);
		}
	}

	public final RelationshipDefinitionContext relationshipDefinition() throws RecognitionException {
		RelationshipDefinitionContext _localctx = new RelationshipDefinitionContext(_ctx, getState());
		enterRule(_localctx, 80, RULE_relationshipDefinition);
		try {
			setState(562);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,40,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(560);
				ownedRelationshipDefinition();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(561);
				mappedRelationshipDefinition();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class MappedRelationshipDefinitionContext extends ParserRuleContext {
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public TerminalNode RELATIONSHIP_SYMBOL() { return getToken(BIDIGrammarParser.RELATIONSHIP_SYMBOL, 0); }
		public TerminalNode MAPPEDBY_SYMBOL() { return getToken(BIDIGrammarParser.MAPPEDBY_SYMBOL, 0); }
		public MappedRelationshipDefinitionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_mappedRelationshipDefinition; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterMappedRelationshipDefinition(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitMappedRelationshipDefinition(this);
		}
	}

	public final MappedRelationshipDefinitionContext mappedRelationshipDefinition() throws RecognitionException {
		MappedRelationshipDefinitionContext _localctx = new MappedRelationshipDefinitionContext(_ctx, getState());
		enterRule(_localctx, 82, RULE_mappedRelationshipDefinition);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(564);
			identifier();
			setState(565);
			identifier();
			setState(566);
			match(RELATIONSHIP_SYMBOL);
			setState(567);
			match(MAPPEDBY_SYMBOL);
			setState(568);
			identifier();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OwnedRelationshipDefinitionContext extends ParserRuleContext {
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public TerminalNode RELATIONSHIP_SYMBOL() { return getToken(BIDIGrammarParser.RELATIONSHIP_SYMBOL, 0); }
		public TerminalNode OPAR_SYMBOL() { return getToken(BIDIGrammarParser.OPAR_SYMBOL, 0); }
		public List<CardinalityContext> cardinality() {
			return getRuleContexts(CardinalityContext.class);
		}
		public CardinalityContext cardinality(int i) {
			return getRuleContext(CardinalityContext.class,i);
		}
		public TerminalNode COMMA_SYMBOL() { return getToken(BIDIGrammarParser.COMMA_SYMBOL, 0); }
		public TerminalNode CPAR_SYMBOL() { return getToken(BIDIGrammarParser.CPAR_SYMBOL, 0); }
		public TerminalNode BIDIRECTIONAL_SYMBOL() { return getToken(BIDIGrammarParser.BIDIRECTIONAL_SYMBOL, 0); }
		public OwnedRelationshipDefinitionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ownedRelationshipDefinition; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterOwnedRelationshipDefinition(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitOwnedRelationshipDefinition(this);
		}
	}

	public final OwnedRelationshipDefinitionContext ownedRelationshipDefinition() throws RecognitionException {
		OwnedRelationshipDefinitionContext _localctx = new OwnedRelationshipDefinitionContext(_ctx, getState());
		enterRule(_localctx, 84, RULE_ownedRelationshipDefinition);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(570);
			identifier();
			setState(571);
			identifier();
			setState(572);
			match(RELATIONSHIP_SYMBOL);
			setState(573);
			match(OPAR_SYMBOL);
			setState(574);
			cardinality();
			setState(575);
			match(COMMA_SYMBOL);
			setState(576);
			cardinality();
			setState(577);
			match(CPAR_SYMBOL);
			setState(579);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==BIDIRECTIONAL_SYMBOL) {
				{
				setState(578);
				match(BIDIRECTIONAL_SYMBOL);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CardinalityContext extends ParserRuleContext {
		public TerminalNode ZERO_ONE_SYMBOL() { return getToken(BIDIGrammarParser.ZERO_ONE_SYMBOL, 0); }
		public TerminalNode ONE_ONE_SYMBOL() { return getToken(BIDIGrammarParser.ONE_ONE_SYMBOL, 0); }
		public TerminalNode ZERO_MANY_SYMBOL() { return getToken(BIDIGrammarParser.ZERO_MANY_SYMBOL, 0); }
		public TerminalNode ONE_MANY_SYMBOL() { return getToken(BIDIGrammarParser.ONE_MANY_SYMBOL, 0); }
		public CardinalityContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cardinality; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterCardinality(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitCardinality(this);
		}
	}

	public final CardinalityContext cardinality() throws RecognitionException {
		CardinalityContext _localctx = new CardinalityContext(_ctx, getState());
		enterRule(_localctx, 86, RULE_cardinality);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(581);
			_la = _input.LA(1);
			if ( !(((((_la - 79)) & ~0x3f) == 0 && ((1L << (_la - 79)) & 15L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SridContext extends ParserRuleContext {
		public TerminalNode INT_NUMBER() { return getToken(BIDIGrammarParser.INT_NUMBER, 0); }
		public SridContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_srid; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterSrid(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitSrid(this);
		}
	}

	public final SridContext srid() throws RecognitionException {
		SridContext _localctx = new SridContext(_ctx, getState());
		enterRule(_localctx, 88, RULE_srid);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(583);
			match(INT_NUMBER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class IdentifierContext extends ParserRuleContext {
		public TerminalNode IDENTIFIER() { return getToken(BIDIGrammarParser.IDENTIFIER, 0); }
		public IdentifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_identifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterIdentifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitIdentifier(this);
		}
	}

	public final IdentifierContext identifier() throws RecognitionException {
		IdentifierContext _localctx = new IdentifierContext(_ctx, getState());
		enterRule(_localctx, 90, RULE_identifier);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(585);
			match(IDENTIFIER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Host_identifierContext extends ParserRuleContext {
		public TerminalNode HOST_IDENTIFIER() { return getToken(BIDIGrammarParser.HOST_IDENTIFIER, 0); }
		public Host_identifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_host_identifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterHost_identifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitHost_identifier(this);
		}
	}

	public final Host_identifierContext host_identifier() throws RecognitionException {
		Host_identifierContext _localctx = new Host_identifierContext(_ctx, getState());
		enterRule(_localctx, 92, RULE_host_identifier);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(587);
			match(HOST_IDENTIFIER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PasswordContext extends ParserRuleContext {
		public List<TerminalNode> STRING_LITERAL() { return getTokens(BIDIGrammarParser.STRING_LITERAL); }
		public TerminalNode STRING_LITERAL(int i) {
			return getToken(BIDIGrammarParser.STRING_LITERAL, i);
		}
		public PasswordContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_password; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterPassword(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitPassword(this);
		}
	}

	public final PasswordContext password() throws RecognitionException {
		PasswordContext _localctx = new PasswordContext(_ctx, getState());
		enterRule(_localctx, 94, RULE_password);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(589);
			match(STRING_LITERAL);
			setState(593);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,42,_ctx);
			while ( _alt!=1 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1+1 ) {
					{
					{
					setState(590);
					match(STRING_LITERAL);
					}
					} 
				}
				setState(595);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,42,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TextContext extends ParserRuleContext {
		public TerminalNode QUOTED_TEXT() { return getToken(BIDIGrammarParser.QUOTED_TEXT, 0); }
		public TextContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_text; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterText(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitText(this);
		}
	}

	public final TextContext text() throws RecognitionException {
		TextContext _localctx = new TextContext(_ctx, getState());
		enterRule(_localctx, 96, RULE_text);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(596);
			match(QUOTED_TEXT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class HexColorContext extends ParserRuleContext {
		public TerminalNode HEX_COLOR() { return getToken(BIDIGrammarParser.HEX_COLOR, 0); }
		public HexColorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_hexColor; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterHexColor(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitHexColor(this);
		}
	}

	public final HexColorContext hexColor() throws RecognitionException {
		HexColorContext _localctx = new HexColorContext(_ctx, getState());
		enterRule(_localctx, 98, RULE_hexColor);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(598);
			match(HEX_COLOR);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FloatNumberContext extends ParserRuleContext {
		public TerminalNode FLOAT_NUMBER() { return getToken(BIDIGrammarParser.FLOAT_NUMBER, 0); }
		public FloatNumberContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_floatNumber; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).enterFloatNumber(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BIDIGrammarListener ) ((BIDIGrammarListener)listener).exitFloatNumber(this);
		}
	}

	public final FloatNumberContext floatNumber() throws RecognitionException {
		FloatNumberContext _localctx = new FloatNumberContext(_ctx, getState());
		enterRule(_localctx, 100, RULE_floatNumber);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(600);
			match(FLOAT_NUMBER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\u0004\u0001f\u025b\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001\u0002"+
		"\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004\u0002"+
		"\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007\u0002"+
		"\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002\u000b\u0007\u000b\u0002"+
		"\f\u0007\f\u0002\r\u0007\r\u0002\u000e\u0007\u000e\u0002\u000f\u0007\u000f"+
		"\u0002\u0010\u0007\u0010\u0002\u0011\u0007\u0011\u0002\u0012\u0007\u0012"+
		"\u0002\u0013\u0007\u0013\u0002\u0014\u0007\u0014\u0002\u0015\u0007\u0015"+
		"\u0002\u0016\u0007\u0016\u0002\u0017\u0007\u0017\u0002\u0018\u0007\u0018"+
		"\u0002\u0019\u0007\u0019\u0002\u001a\u0007\u001a\u0002\u001b\u0007\u001b"+
		"\u0002\u001c\u0007\u001c\u0002\u001d\u0007\u001d\u0002\u001e\u0007\u001e"+
		"\u0002\u001f\u0007\u001f\u0002 \u0007 \u0002!\u0007!\u0002\"\u0007\"\u0002"+
		"#\u0007#\u0002$\u0007$\u0002%\u0007%\u0002&\u0007&\u0002\'\u0007\'\u0002"+
		"(\u0007(\u0002)\u0007)\u0002*\u0007*\u0002+\u0007+\u0002,\u0007,\u0002"+
		"-\u0007-\u0002.\u0007.\u0002/\u0007/\u00020\u00070\u00021\u00071\u0002"+
		"2\u00072\u0001\u0000\u0004\u0000h\b\u0000\u000b\u0000\f\u0000i\u0001\u0001"+
		"\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001"+
		"\u0001\u0001\u0003\u0001t\b\u0001\u0001\u0002\u0001\u0002\u0001\u0002"+
		"\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0003\u0002}\b\u0002"+
		"\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003"+
		"\u0003\u0003\u0085\b\u0003\u0001\u0004\u0001\u0004\u0001\u0004\u0001\u0004"+
		"\u0003\u0004\u008b\b\u0004\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005"+
		"\u0001\u0005\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006"+
		"\u0001\u0006\u0001\u0006\u0005\u0006\u0099\b\u0006\n\u0006\f\u0006\u009c"+
		"\t\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0003\u0006\u00a1\b\u0006"+
		"\u0001\u0006\u0001\u0006\u0001\u0007\u0001\u0007\u0001\u0007\u0001\u0007"+
		"\u0005\u0007\u00a9\b\u0007\n\u0007\f\u0007\u00ac\t\u0007\u0001\b\u0001"+
		"\b\u0001\b\u0003\b\u00b1\b\b\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001"+
		"\t\u0001\t\u0001\t\u0001\t\u0001\t\u0003\t\u00bd\b\t\u0005\t\u00bf\b\t"+
		"\n\t\f\t\u00c2\t\t\u0001\t\u0001\t\u0001\t\u0001\t\u0005\t\u00c8\b\t\n"+
		"\t\f\t\u00cb\t\t\u0003\t\u00cd\b\t\u0001\t\u0003\t\u00d0\b\t\u0003\t\u00d2"+
		"\b\t\u0001\t\u0001\t\u0001\n\u0001\n\u0001\n\u0005\n\u00d9\b\n\n\n\f\n"+
		"\u00dc\t\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0003"+
		"\n\u00e5\b\n\u0005\n\u00e7\b\n\n\n\f\n\u00ea\t\n\u0001\n\u0001\n\u0001"+
		"\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0005"+
		"\n\u00f7\b\n\n\n\f\n\u00fa\t\n\u0001\n\u0001\n\u0003\n\u00fe\b\n\u0001"+
		"\n\u0001\n\u0001\n\u0005\n\u0103\b\n\n\n\f\n\u0106\t\n\u0003\n\u0108\b"+
		"\n\u0001\n\u0003\n\u010b\b\n\u0001\n\u0001\n\u0001\u000b\u0001\u000b\u0001"+
		"\u000b\u0003\u000b\u0112\b\u000b\u0001\u000b\u0003\u000b\u0115\b\u000b"+
		"\u0001\u000b\u0001\u000b\u0001\u000b\u0003\u000b\u011a\b\u000b\u0001\f"+
		"\u0001\f\u0001\f\u0001\f\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001"+
		"\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001"+
		"\u000e\u0001\u000e\u0001\u000e\u0001\u000e\u0001\u000e\u0001\u000e\u0001"+
		"\u000e\u0001\u000e\u0001\u000e\u0001\u000e\u0001\u000e\u0001\u000e\u0001"+
		"\u000e\u0001\u000f\u0001\u000f\u0001\u000f\u0001\u000f\u0001\u000f\u0001"+
		"\u000f\u0001\u000f\u0001\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0001"+
		"\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0001"+
		"\u0011\u0001\u0011\u0001\u0011\u0001\u0011\u0001\u0011\u0001\u0011\u0001"+
		"\u0011\u0001\u0011\u0001\u0011\u0001\u0011\u0001\u0011\u0001\u0012\u0001"+
		"\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0001"+
		"\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0003"+
		"\u0012\u0164\b\u0012\u0005\u0012\u0166\b\u0012\n\u0012\f\u0012\u0169\t"+
		"\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0001\u0013\u0001"+
		"\u0013\u0001\u0013\u0001\u0013\u0003\u0013\u0173\b\u0013\u0001\u0013\u0001"+
		"\u0013\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001"+
		"\u0014\u0001\u0014\u0005\u0014\u017e\b\u0014\n\u0014\f\u0014\u0181\t\u0014"+
		"\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014"+
		"\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0003\u0014"+
		"\u018e\b\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014"+
		"\u0001\u0014\u0001\u0014\u0003\u0014\u0197\b\u0014\u0001\u0014\u0001\u0014"+
		"\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015"+
		"\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0016\u0001\u0016\u0001\u0016"+
		"\u0001\u0016\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0018"+
		"\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018"+
		"\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0019\u0001\u0019\u0001\u0019"+
		"\u0001\u0019\u0001\u001a\u0001\u001a\u0001\u001a\u0001\u001a\u0001\u001a"+
		"\u0001\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0001\u001c"+
		"\u0001\u001c\u0001\u001c\u0001\u001c\u0001\u001c\u0001\u001c\u0001\u001c"+
		"\u0001\u001c\u0001\u001c\u0001\u001c\u0001\u001c\u0001\u001c\u0001\u001c"+
		"\u0001\u001c\u0001\u001c\u0001\u001c\u0001\u001c\u0001\u001c\u0001\u001c"+
		"\u0001\u001c\u0001\u001d\u0001\u001d\u0001\u001d\u0001\u001d\u0001\u001d"+
		"\u0001\u001d\u0005\u001d\u01de\b\u001d\n\u001d\f\u001d\u01e1\t\u001d\u0001"+
		"\u001d\u0001\u001d\u0001\u001d\u0001\u001e\u0001\u001e\u0001\u001e\u0001"+
		"\u001e\u0003\u001e\u01ea\b\u001e\u0001\u001e\u0001\u001e\u0001\u001f\u0001"+
		"\u001f\u0001\u001f\u0001\u001f\u0001 \u0001 \u0001 \u0001!\u0001!\u0001"+
		"!\u0001!\u0001\"\u0001\"\u0001\"\u0001\"\u0001#\u0001#\u0001#\u0001#\u0005"+
		"#\u0201\b#\n#\f#\u0204\t#\u0001#\u0001#\u0001#\u0001#\u0001#\u0001#\u0001"+
		"#\u0001#\u0001#\u0001#\u0001#\u0003#\u0211\b#\u0001#\u0001#\u0001#\u0001"+
		"#\u0001#\u0001#\u0001#\u0003#\u021a\b#\u0001$\u0001$\u0001%\u0001%\u0001"+
		"&\u0001&\u0003&\u0222\b&\u0001\'\u0001\'\u0001\'\u0001\'\u0001\'\u0001"+
		"\'\u0001\'\u0001\'\u0005\'\u022c\b\'\n\'\f\'\u022f\t\'\u0001(\u0001(\u0003"+
		"(\u0233\b(\u0001)\u0001)\u0001)\u0001)\u0001)\u0001)\u0001*\u0001*\u0001"+
		"*\u0001*\u0001*\u0001*\u0001*\u0001*\u0001*\u0003*\u0244\b*\u0001+\u0001"+
		"+\u0001,\u0001,\u0001-\u0001-\u0001.\u0001.\u0001/\u0001/\u0005/\u0250"+
		"\b/\n/\f/\u0253\t/\u00010\u00010\u00011\u00011\u00012\u00012\u00012\u0004"+
		"\u00aa\u00da\u00f8\u0251\u00003\u0000\u0002\u0004\u0006\b\n\f\u000e\u0010"+
		"\u0012\u0014\u0016\u0018\u001a\u001c\u001e \"$&(*,.02468:<>@BDFHJLNPR"+
		"TVXZ\\^`bd\u0000\u0001\u0001\u0000OR\u0262\u0000g\u0001\u0000\u0000\u0000"+
		"\u0002s\u0001\u0000\u0000\u0000\u0004u\u0001\u0000\u0000\u0000\u0006~"+
		"\u0001\u0000\u0000\u0000\b\u0086\u0001\u0000\u0000\u0000\n\u008c\u0001"+
		"\u0000\u0000\u0000\f\u0091\u0001\u0000\u0000\u0000\u000e\u00a4\u0001\u0000"+
		"\u0000\u0000\u0010\u00ad\u0001\u0000\u0000\u0000\u0012\u00b2\u0001\u0000"+
		"\u0000\u0000\u0014\u00d5\u0001\u0000\u0000\u0000\u0016\u0111\u0001\u0000"+
		"\u0000\u0000\u0018\u011b\u0001\u0000\u0000\u0000\u001a\u011f\u0001\u0000"+
		"\u0000\u0000\u001c\u012d\u0001\u0000\u0000\u0000\u001e\u013a\u0001\u0000"+
		"\u0000\u0000 \u0141\u0001\u0000\u0000\u0000\"\u014b\u0001\u0000\u0000"+
		"\u0000$\u0156\u0001\u0000\u0000\u0000&\u016e\u0001\u0000\u0000\u0000("+
		"\u0176\u0001\u0000\u0000\u0000*\u019a\u0001\u0000\u0000\u0000,\u01a3\u0001"+
		"\u0000\u0000\u0000.\u01a7\u0001\u0000\u0000\u00000\u01ab\u0001\u0000\u0000"+
		"\u00002\u01b5\u0001\u0000\u0000\u00004\u01b9\u0001\u0000\u0000\u00006"+
		"\u01be\u0001\u0000\u0000\u00008\u01c3\u0001\u0000\u0000\u0000:\u01d7\u0001"+
		"\u0000\u0000\u0000<\u01e5\u0001\u0000\u0000\u0000>\u01ed\u0001\u0000\u0000"+
		"\u0000@\u01f1\u0001\u0000\u0000\u0000B\u01f4\u0001\u0000\u0000\u0000D"+
		"\u01f8\u0001\u0000\u0000\u0000F\u01fc\u0001\u0000\u0000\u0000H\u021b\u0001"+
		"\u0000\u0000\u0000J\u021d\u0001\u0000\u0000\u0000L\u0221\u0001\u0000\u0000"+
		"\u0000N\u0223\u0001\u0000\u0000\u0000P\u0232\u0001\u0000\u0000\u0000R"+
		"\u0234\u0001\u0000\u0000\u0000T\u023a\u0001\u0000\u0000\u0000V\u0245\u0001"+
		"\u0000\u0000\u0000X\u0247\u0001\u0000\u0000\u0000Z\u0249\u0001\u0000\u0000"+
		"\u0000\\\u024b\u0001\u0000\u0000\u0000^\u024d\u0001\u0000\u0000\u0000"+
		"`\u0254\u0001\u0000\u0000\u0000b\u0256\u0001\u0000\u0000\u0000d\u0258"+
		"\u0001\u0000\u0000\u0000fh\u0003\u0002\u0001\u0000gf\u0001\u0000\u0000"+
		"\u0000hi\u0001\u0000\u0000\u0000ig\u0001\u0000\u0000\u0000ij\u0001\u0000"+
		"\u0000\u0000j\u0001\u0001\u0000\u0000\u0000kt\u0003\u0004\u0002\u0000"+
		"lt\u0003$\u0012\u0000mt\u0003\u0006\u0003\u0000nt\u0003\b\u0004\u0000"+
		"ot\u0003\n\u0005\u0000pt\u0003\u0010\b\u0000qt\u0003\f\u0006\u0000rt\u0003"+
		"&\u0013\u0000sk\u0001\u0000\u0000\u0000sl\u0001\u0000\u0000\u0000sm\u0001"+
		"\u0000\u0000\u0000sn\u0001\u0000\u0000\u0000so\u0001\u0000\u0000\u0000"+
		"sp\u0001\u0000\u0000\u0000sq\u0001\u0000\u0000\u0000sr\u0001\u0000\u0000"+
		"\u0000t\u0003\u0001\u0000\u0000\u0000uv\u0005\u0003\u0000\u0000vw\u0005"+
		"B\u0000\u0000w|\u0003Z-\u0000x}\u0003,\u0016\u0000y}\u0003.\u0017\u0000"+
		"z}\u00030\u0018\u0000{}\u0003>\u001f\u0000|x\u0001\u0000\u0000\u0000|"+
		"y\u0001\u0000\u0000\u0000|z\u0001\u0000\u0000\u0000|{\u0001\u0000\u0000"+
		"\u0000}\u0005\u0001\u0000\u0000\u0000~\u0084\u0005\u000e\u0000\u0000\u007f"+
		"\u0085\u00032\u0019\u0000\u0080\u0085\u00034\u001a\u0000\u0081\u0085\u0003"+
		"6\u001b\u0000\u0082\u0085\u0003:\u001d\u0000\u0083\u0085\u0003<\u001e"+
		"\u0000\u0084\u007f\u0001\u0000\u0000\u0000\u0084\u0080\u0001\u0000\u0000"+
		"\u0000\u0084\u0081\u0001\u0000\u0000\u0000\u0084\u0082\u0001\u0000\u0000"+
		"\u0000\u0084\u0083\u0001\u0000\u0000\u0000\u0085\u0007\u0001\u0000\u0000"+
		"\u0000\u0086\u008a\u0005\u0014\u0000\u0000\u0087\u008b\u0003@ \u0000\u0088"+
		"\u008b\u0003B!\u0000\u0089\u008b\u0003D\"\u0000\u008a\u0087\u0001\u0000"+
		"\u0000\u0000\u008a\u0088\u0001\u0000\u0000\u0000\u008a\u0089\u0001\u0000"+
		"\u0000\u0000\u008b\t\u0001\u0000\u0000\u0000\u008c\u008d\u0005\u001e\u0000"+
		"\u0000\u008d\u008e\u0005<\u0000\u0000\u008e\u008f\u0003Z-\u0000\u008f"+
		"\u0090\u0005Y\u0000\u0000\u0090\u000b\u0001\u0000\u0000\u0000\u0091\u0092"+
		"\u0005%\u0000\u0000\u0092\u0093\u0005&\u0000\u0000\u0093\u0094\u0003Z"+
		"-\u0000\u0094\u0095\u0005V\u0000\u0000\u0095\u009a\u0003Z-\u0000\u0096"+
		"\u0097\u0005X\u0000\u0000\u0097\u0099\u0003Z-\u0000\u0098\u0096\u0001"+
		"\u0000\u0000\u0000\u0099\u009c\u0001\u0000\u0000\u0000\u009a\u0098\u0001"+
		"\u0000\u0000\u0000\u009a\u009b\u0001\u0000\u0000\u0000\u009b\u009d\u0001"+
		"\u0000\u0000\u0000\u009c\u009a\u0001\u0000\u0000\u0000\u009d\u00a0\u0005"+
		"W\u0000\u0000\u009e\u00a1\u0003\u000e\u0007\u0000\u009f\u00a1\u0003F#"+
		"\u0000\u00a0\u009e\u0001\u0000\u0000\u0000\u00a0\u009f\u0001\u0000\u0000"+
		"\u0000\u00a1\u00a2\u0001\u0000\u0000\u0000\u00a2\u00a3\u0005Y\u0000\u0000"+
		"\u00a3\r\u0001\u0000\u0000\u0000\u00a4\u00a5\u0005\\\u0000\u0000\u00a5"+
		"\u00aa\u0003J%\u0000\u00a6\u00a7\u0005X\u0000\u0000\u00a7\u00a9\u0003"+
		"J%\u0000\u00a8\u00a6\u0001\u0000\u0000\u0000\u00a9\u00ac\u0001\u0000\u0000"+
		"\u0000\u00aa\u00ab\u0001\u0000\u0000\u0000\u00aa\u00a8\u0001\u0000\u0000"+
		"\u0000\u00ab\u000f\u0001\u0000\u0000\u0000\u00ac\u00aa\u0001\u0000\u0000"+
		"\u0000\u00ad\u00b0\u0005)\u0000\u0000\u00ae\u00b1\u0003\u0012\t\u0000"+
		"\u00af\u00b1\u0003\u0014\n\u0000\u00b0\u00ae\u0001\u0000\u0000\u0000\u00b0"+
		"\u00af\u0001\u0000\u0000\u0000\u00b1\u0011\u0001\u0000\u0000\u0000\u00b2"+
		"\u00b3\u0005\u0002\u0000\u0000\u00b3\u00b4\u00055\u0000\u0000\u00b4\u00b5"+
		"\u0003Z-\u0000\u00b5\u00b6\u0005C\u0000\u0000\u00b6\u00d1\u0003Z-\u0000"+
		"\u00b7\u00b8\u0005V\u0000\u0000\u00b8\u00c0\u0003\u0016\u000b\u0000\u00b9"+
		"\u00bc\u0005X\u0000\u0000\u00ba\u00bd\u0003\u0016\u000b\u0000\u00bb\u00bd"+
		"\u0003\u001a\r\u0000\u00bc\u00ba\u0001\u0000\u0000\u0000\u00bc\u00bb\u0001"+
		"\u0000\u0000\u0000\u00bd\u00bf\u0001\u0000\u0000\u0000\u00be\u00b9\u0001"+
		"\u0000\u0000\u0000\u00bf\u00c2\u0001\u0000\u0000\u0000\u00c0\u00be\u0001"+
		"\u0000\u0000\u0000\u00c0\u00c1\u0001\u0000\u0000\u0000\u00c1\u00c3\u0001"+
		"\u0000\u0000\u0000\u00c2\u00c0\u0001\u0000\u0000\u0000\u00c3\u00cc\u0005"+
		"W\u0000\u0000\u00c4\u00c9\u0003 \u0010\u0000\u00c5\u00c6\u0005X\u0000"+
		"\u0000\u00c6\u00c8\u0003 \u0010\u0000\u00c7\u00c5\u0001\u0000\u0000\u0000"+
		"\u00c8\u00cb\u0001\u0000\u0000\u0000\u00c9\u00c7\u0001\u0000\u0000\u0000"+
		"\u00c9\u00ca\u0001\u0000\u0000\u0000\u00ca\u00cd\u0001\u0000\u0000\u0000"+
		"\u00cb\u00c9\u0001\u0000\u0000\u0000\u00cc\u00c4\u0001\u0000\u0000\u0000"+
		"\u00cc\u00cd\u0001\u0000\u0000\u0000\u00cd\u00cf\u0001\u0000\u0000\u0000"+
		"\u00ce\u00d0\u0003\"\u0011\u0000\u00cf\u00ce\u0001\u0000\u0000\u0000\u00cf"+
		"\u00d0\u0001\u0000\u0000\u0000\u00d0\u00d2\u0001\u0000\u0000\u0000\u00d1"+
		"\u00b7\u0001\u0000\u0000\u0000\u00d1\u00d2\u0001\u0000\u0000\u0000\u00d2"+
		"\u00d3\u0001\u0000\u0000\u0000\u00d3\u00d4\u0005Y\u0000\u0000\u00d4\u0013"+
		"\u0001\u0000\u0000\u0000\u00d5\u00da\u0003Z-\u0000\u00d6\u00d7\u0005X"+
		"\u0000\u0000\u00d7\u00d9\u0003Z-\u0000\u00d8\u00d6\u0001\u0000\u0000\u0000"+
		"\u00d9\u00dc\u0001\u0000\u0000\u0000\u00da\u00db\u0001\u0000\u0000\u0000"+
		"\u00da\u00d8\u0001\u0000\u0000\u0000\u00db\u00dd\u0001\u0000\u0000\u0000"+
		"\u00dc\u00da\u0001\u0000\u0000\u0000\u00dd\u00de\u0005C\u0000\u0000\u00de"+
		"\u00df\u0003Z-\u0000\u00df\u00e0\u0005V\u0000\u0000\u00e0\u00e8\u0003"+
		"\u0016\u000b\u0000\u00e1\u00e4\u0005X\u0000\u0000\u00e2\u00e5\u0003\u0016"+
		"\u000b\u0000\u00e3\u00e5\u0003\u001a\r\u0000\u00e4\u00e2\u0001\u0000\u0000"+
		"\u0000\u00e4\u00e3\u0001\u0000\u0000\u0000\u00e5\u00e7\u0001\u0000\u0000"+
		"\u0000\u00e6\u00e1\u0001\u0000\u0000\u0000\u00e7\u00ea\u0001\u0000\u0000"+
		"\u0000\u00e8\u00e6\u0001\u0000\u0000\u0000\u00e8\u00e9\u0001\u0000\u0000"+
		"\u0000\u00e9\u00eb\u0001\u0000\u0000\u0000\u00ea\u00e8\u0001\u0000\u0000"+
		"\u0000\u00eb\u00fd\u0005W\u0000\u0000\u00ec\u00ed\u0005L\u0000\u0000\u00ed"+
		"\u00ee\u0005V\u0000\u0000\u00ee\u00ef\u0003Z-\u0000\u00ef\u00f0\u0005"+
		"\\\u0000\u0000\u00f0\u00f8\u0003Z-\u0000\u00f1\u00f2\u0005\u0004\u0000"+
		"\u0000\u00f2\u00f3\u0003Z-\u0000\u00f3\u00f4\u0005\\\u0000\u0000\u00f4"+
		"\u00f5\u0003Z-\u0000\u00f5\u00f7\u0001\u0000\u0000\u0000\u00f6\u00f1\u0001"+
		"\u0000\u0000\u0000\u00f7\u00fa\u0001\u0000\u0000\u0000\u00f8\u00f9\u0001"+
		"\u0000\u0000\u0000\u00f8\u00f6\u0001\u0000\u0000\u0000\u00f9\u00fb\u0001"+
		"\u0000\u0000\u0000\u00fa\u00f8\u0001\u0000\u0000\u0000\u00fb\u00fc\u0005"+
		"W\u0000\u0000\u00fc\u00fe\u0001\u0000\u0000\u0000\u00fd\u00ec\u0001\u0000"+
		"\u0000\u0000\u00fd\u00fe\u0001\u0000\u0000\u0000\u00fe\u0107\u0001\u0000"+
		"\u0000\u0000\u00ff\u0104\u0003 \u0010\u0000\u0100\u0101\u0005X\u0000\u0000"+
		"\u0101\u0103\u0003 \u0010\u0000\u0102\u0100\u0001\u0000\u0000\u0000\u0103"+
		"\u0106\u0001\u0000\u0000\u0000\u0104\u0102\u0001\u0000\u0000\u0000\u0104"+
		"\u0105\u0001\u0000\u0000\u0000\u0105\u0108\u0001\u0000\u0000\u0000\u0106"+
		"\u0104\u0001\u0000\u0000\u0000\u0107\u00ff\u0001\u0000\u0000\u0000\u0107"+
		"\u0108\u0001\u0000\u0000\u0000\u0108\u010a\u0001\u0000\u0000\u0000\u0109"+
		"\u010b\u0003\"\u0011\u0000\u010a\u0109\u0001\u0000\u0000\u0000\u010a\u010b"+
		"\u0001\u0000\u0000\u0000\u010b\u010c\u0001\u0000\u0000\u0000\u010c\u010d"+
		"\u0005Y\u0000\u0000\u010d\u0015\u0001\u0000\u0000\u0000\u010e\u0112\u0003"+
		"Z-\u0000\u010f\u0112\u0005.\u0000\u0000\u0110\u0112\u0003\u0018\f\u0000"+
		"\u0111\u010e\u0001\u0000\u0000\u0000\u0111\u010f\u0001\u0000\u0000\u0000"+
		"\u0111\u0110\u0001\u0000\u0000\u0000\u0112\u0114\u0001\u0000\u0000\u0000"+
		"\u0113\u0115\u0005S\u0000\u0000\u0114\u0113\u0001\u0000\u0000\u0000\u0114"+
		"\u0115\u0001\u0000\u0000\u0000\u0115\u0116\u0001\u0000\u0000\u0000\u0116"+
		"\u0117\u0005C\u0000\u0000\u0117\u0119\u0003Z-\u0000\u0118\u011a\u0003"+
		"\u001e\u000f\u0000\u0119\u0118\u0001\u0000\u0000\u0000\u0119\u011a\u0001"+
		"\u0000\u0000\u0000\u011a\u0017\u0001\u0000\u0000\u0000\u011b\u011c\u0005"+
		"A\u0000\u0000\u011c\u011d\u0005Z\u0000\u0000\u011d\u011e\u0005f\u0000"+
		"\u0000\u011e\u0019\u0001\u0000\u0000\u0000\u011f\u0120\u0005:\u0000\u0000"+
		"\u0120\u0121\u00057\u0000\u0000\u0121\u0122\u0003Z-\u0000\u0122\u0123"+
		"\u0005U\u0000\u0000\u0123\u0124\u0003Z-\u0000\u0124\u0125\u0005\u0005"+
		"\u0000\u0000\u0125\u0126\u0003Z-\u0000\u0126\u0127\u0005S\u0000\u0000"+
		"\u0127\u0128\u0005\u0017\u0000\u0000\u0128\u0129\u0003Z-\u0000\u0129\u012a"+
		"\u0005U\u0000\u0000\u012a\u012b\u0003Z-\u0000\u012b\u012c\u0005S\u0000"+
		"\u0000\u012c\u001b\u0001\u0000\u0000\u0000\u012d\u012e\u0005\'\u0000\u0000"+
		"\u012e\u012f\u0005V\u0000\u0000\u012f\u0130\u0003Z-\u0000\u0130\u0131"+
		"\u0005U\u0000\u0000\u0131\u0132\u0003Z-\u0000\u0132\u0133\u0005S\u0000"+
		"\u0000\u0133\u0134\u0005\\\u0000\u0000\u0134\u0135\u0003Z-\u0000\u0135"+
		"\u0136\u0005U\u0000\u0000\u0136\u0137\u0003Z-\u0000\u0137\u0138\u0005"+
		"S\u0000\u0000\u0138\u0139\u0005W\u0000\u0000\u0139\u001d\u0001\u0000\u0000"+
		"\u0000\u013a\u013b\u0005\u001d\u0000\u0000\u013b\u013c\u0005(\u0000\u0000"+
		"\u013c\u013d\u0003Z-\u0000\u013d\u013e\u0005V\u0000\u0000\u013e\u013f"+
		"\u0003Z-\u0000\u013f\u0140\u0005W\u0000\u0000\u0140\u001f\u0001\u0000"+
		"\u0000\u0000\u0141\u0142\u0005\u001d\u0000\u0000\u0142\u0143\u0005(\u0000"+
		"\u0000\u0143\u0144\u0003Z-\u0000\u0144\u0145\u0005U\u0000\u0000\u0145"+
		"\u0146\u0003Z-\u0000\u0146\u0147\u00056\u0000\u0000\u0147\u0148\u0003"+
		"Z-\u0000\u0148\u0149\u0005U\u0000\u0000\u0149\u014a\u0003Z-\u0000\u014a"+
		"!\u0001\u0000\u0000\u0000\u014b\u014c\u0005\u001f\u0000\u0000\u014c\u014d"+
		"\u0003Z-\u0000\u014d\u014e\u0005\u001b\u0000\u0000\u014e\u014f\u0003Z"+
		"-\u0000\u014f\u0150\u0005U\u0000\u0000\u0150\u0151\u0003Z-\u0000\u0151"+
		"\u0152\u0005K\u0000\u0000\u0152\u0153\u0003Z-\u0000\u0153\u0154\u0005"+
		"\\\u0000\u0000\u0154\u0155\u0003Z-\u0000\u0155#\u0001\u0000\u0000\u0000"+
		"\u0156\u0157\u0005\u0006\u0000\u0000\u0157\u0158\u0003Z-\u0000\u0158\u0159"+
		"\u0005V\u0000\u0000\u0159\u015a\u0003Z-\u0000\u015a\u015b\u0005W\u0000"+
		"\u0000\u015b\u015c\u0005C\u0000\u0000\u015c\u015d\u0005B\u0000\u0000\u015d"+
		"\u015e\u0003Z-\u0000\u015e\u015f\u0005V\u0000\u0000\u015f\u0167\u0003"+
		"\u0016\u000b\u0000\u0160\u0163\u0005X\u0000\u0000\u0161\u0164\u0003\u0016"+
		"\u000b\u0000\u0162\u0164\u0003\u001a\r\u0000\u0163\u0161\u0001\u0000\u0000"+
		"\u0000\u0163\u0162\u0001\u0000\u0000\u0000\u0164\u0166\u0001\u0000\u0000"+
		"\u0000\u0165\u0160\u0001\u0000\u0000\u0000\u0166\u0169\u0001\u0000\u0000"+
		"\u0000\u0167\u0165\u0001\u0000\u0000\u0000\u0167\u0168\u0001\u0000\u0000"+
		"\u0000\u0168\u016a\u0001\u0000\u0000\u0000\u0169\u0167\u0001\u0000\u0000"+
		"\u0000\u016a\u016b\u0005W\u0000\u0000\u016b\u016c\u0003 \u0010\u0000\u016c"+
		"\u016d\u0005Y\u0000\u0000\u016d%\u0001\u0000\u0000\u0000\u016e\u016f\u0005"+
		"E\u0000\u0000\u016f\u0172\u0003Z-\u0000\u0170\u0173\u0003(\u0014\u0000"+
		"\u0171\u0173\u0003*\u0015\u0000\u0172\u0170\u0001\u0000\u0000\u0000\u0172"+
		"\u0171\u0001\u0000\u0000\u0000\u0173\u0174\u0001\u0000\u0000\u0000\u0174"+
		"\u0175\u0005Y\u0000\u0000\u0175\'\u0001\u0000\u0000\u0000\u0176\u0177"+
		"\u0005?\u0000\u0000\u0177\u0178\u0003H$\u0000\u0178\u0179\u0005\\\u0000"+
		"\u0000\u0179\u017a\u0005V\u0000\u0000\u017a\u017f\u0003Z-\u0000\u017b"+
		"\u017c\u0005X\u0000\u0000\u017c\u017e\u0003Z-\u0000\u017d\u017b\u0001"+
		"\u0000\u0000\u0000\u017e\u0181\u0001\u0000\u0000\u0000\u017f\u017d\u0001"+
		"\u0000\u0000\u0000\u017f\u0180\u0001\u0000\u0000\u0000\u0180\u0182\u0001"+
		"\u0000\u0000\u0000\u0181\u017f\u0001\u0000\u0000\u0000\u0182\u0183\u0005"+
		"\u001b\u0000\u0000\u0183\u018d\u0003Z-\u0000\u0184\u0185\u0005U\u0000"+
		"\u0000\u0185\u0186\u0003Z-\u0000\u0186\u0187\u0005\\\u0000\u0000\u0187"+
		"\u0188\u0003Z-\u0000\u0188\u0189\u0005U\u0000\u0000\u0189\u018a\u0003"+
		"Z-\u0000\u018a\u018b\u0005U\u0000\u0000\u018b\u018c\u0005c\u0000\u0000"+
		"\u018c\u018e\u0001\u0000\u0000\u0000\u018d\u0184\u0001\u0000\u0000\u0000"+
		"\u018d\u018e\u0001\u0000\u0000\u0000\u018e\u0196\u0001\u0000\u0000\u0000"+
		"\u018f\u0190\u0005L\u0000\u0000\u0190\u0191\u0003Z-\u0000\u0191\u0192"+
		"\u0005\\\u0000\u0000\u0192\u0193\u0003Z-\u0000\u0193\u0194\u0005U\u0000"+
		"\u0000\u0194\u0195\u0003Z-\u0000\u0195\u0197\u0001\u0000\u0000\u0000\u0196"+
		"\u018f\u0001\u0000\u0000\u0000\u0196\u0197\u0001\u0000\u0000\u0000\u0197"+
		"\u0198\u0001\u0000\u0000\u0000\u0198\u0199\u0005W\u0000\u0000\u0199)\u0001"+
		"\u0000\u0000\u0000\u019a\u019b\u0005\u001d\u0000\u0000\u019b\u019c\u0005"+
		"(\u0000\u0000\u019c\u019d\u0003Z-\u0000\u019d\u019e\u00056\u0000\u0000"+
		"\u019e\u019f\u0003Z-\u0000\u019f\u01a0\u0005V\u0000\u0000\u01a0\u01a1"+
		"\u0003Z-\u0000\u01a1\u01a2\u0005W\u0000\u0000\u01a2+\u0001\u0000\u0000"+
		"\u0000\u01a3\u01a4\u0005\u0001\u0000\u0000\u01a4\u01a5\u0003L&\u0000\u01a5"+
		"\u01a6\u0005Y\u0000\u0000\u01a6-\u0001\u0000\u0000\u0000\u01a7\u01a8\u0005"+
		"\u0001\u0000\u0000\u01a8\u01a9\u0005\r\u0000\u0000\u01a9\u01aa\u0003Z"+
		"-\u0000\u01aa/\u0001\u0000\u0000\u0000\u01ab\u01ac\u0005\u0001\u0000\u0000"+
		"\u01ac\u01ad\u0005\u001d\u0000\u0000\u01ad\u01ae\u0005(\u0000\u0000\u01ae"+
		"\u01af\u0005V\u0000\u0000\u01af\u01b0\u0003Z-\u0000\u01b0\u01b1\u0005"+
		"W\u0000\u0000\u01b1\u01b2\u00056\u0000\u0000\u01b2\u01b3\u0003Z-\u0000"+
		"\u01b3\u01b4\u0005Y\u0000\u0000\u01b41\u0001\u0000\u0000\u0000\u01b5\u01b6"+
		"\u00054\u0000\u0000\u01b6\u01b7\u0003Z-\u0000\u01b7\u01b8\u0005Y\u0000"+
		"\u0000\u01b83\u0001\u0000\u0000\u0000\u01b9\u01ba\u0005\f\u0000\u0000"+
		"\u01ba\u01bb\u0005C\u0000\u0000\u01bb\u01bc\u00038\u001c\u0000\u01bc\u01bd"+
		"\u0005Y\u0000\u0000\u01bd5\u0001\u0000\u0000\u0000\u01be\u01bf\u0005\f"+
		"\u0000\u0000\u01bf\u01c0\u0005\u001b\u0000\u0000\u01c0\u01c1\u00038\u001c"+
		"\u0000\u01c1\u01c2\u0005Y\u0000\u0000\u01c27\u0001\u0000\u0000\u0000\u01c3"+
		"\u01c4\u0005V\u0000\u0000\u01c4\u01c5\u0005\u0011\u0000\u0000\u01c5\u01c6"+
		"\u0003Z-\u0000\u01c6\u01c7\u0005X\u0000\u0000\u01c7\u01c8\u0005!\u0000"+
		"\u0000\u01c8\u01c9\u0003Z-\u0000\u01c9\u01ca\u0005X\u0000\u0000\u01ca"+
		"\u01cb\u00051\u0000\u0000\u01cb\u01cc\u0005_\u0000\u0000\u01cc\u01cd\u0005"+
		"X\u0000\u0000\u01cd\u01ce\u0005H\u0000\u0000\u01ce\u01cf\u0003Z-\u0000"+
		"\u01cf\u01d0\u0005X\u0000\u0000\u01d0\u01d1\u00050\u0000\u0000\u01d1\u01d2"+
		"\u0003Z-\u0000\u01d2\u01d3\u0005X\u0000\u0000\u01d3\u01d4\u0005;\u0000"+
		"\u0000\u01d4\u01d5\u0003Z-\u0000\u01d5\u01d6\u0005W\u0000\u0000\u01d6"+
		"9\u0001\u0000\u0000\u0000\u01d7\u01d8\u0005\u0016\u0000\u0000\u01d8\u01d9"+
		"\u0003Z-\u0000\u01d9\u01da\u0005V\u0000\u0000\u01da\u01df\u0003L&\u0000"+
		"\u01db\u01dc\u0005X\u0000\u0000\u01dc\u01de\u0003L&\u0000\u01dd\u01db"+
		"\u0001\u0000\u0000\u0000\u01de\u01e1\u0001\u0000\u0000\u0000\u01df\u01dd"+
		"\u0001\u0000\u0000\u0000\u01df\u01e0\u0001\u0000\u0000\u0000\u01e0\u01e2"+
		"\u0001\u0000\u0000\u0000\u01e1\u01df\u0001\u0000\u0000\u0000\u01e2\u01e3"+
		"\u0005W\u0000\u0000\u01e3\u01e4\u0005Y\u0000\u0000\u01e4;\u0001\u0000"+
		"\u0000\u0000\u01e5\u01e6\u0005;\u0000\u0000\u01e6\u01e9\u0003Z-\u0000"+
		"\u01e7\u01e8\u0005\u0007\u0000\u0000\u01e8\u01ea\u0003Z-\u0000\u01e9\u01e7"+
		"\u0001\u0000\u0000\u0000\u01e9\u01ea\u0001\u0000\u0000\u0000\u01ea\u01eb"+
		"\u0001\u0000\u0000\u0000\u01eb\u01ec\u0005Y\u0000\u0000\u01ec=\u0001\u0000"+
		"\u0000\u0000\u01ed\u01ee\u0005\u0014\u0000\u0000\u01ee\u01ef\u0003Z-\u0000"+
		"\u01ef\u01f0\u0005Y\u0000\u0000\u01f0?\u0001\u0000\u0000\u0000\u01f1\u01f2"+
		"\u0005\f\u0000\u0000\u01f2\u01f3\u0005Y\u0000\u0000\u01f3A\u0001\u0000"+
		"\u0000\u0000\u01f4\u01f5\u0005;\u0000\u0000\u01f5\u01f6\u0003Z-\u0000"+
		"\u01f6\u01f7\u0005Y\u0000\u0000\u01f7C\u0001\u0000\u0000\u0000\u01f8\u01f9"+
		"\u0005B\u0000\u0000\u01f9\u01fa\u0003Z-\u0000\u01fa\u01fb\u0005Y\u0000"+
		"\u0000\u01fbE\u0001\u0000\u0000\u0000\u01fc\u01fd\u0005=\u0000\u0000\u01fd"+
		"\u0202\u0003Z-\u0000\u01fe\u01ff\u0005X\u0000\u0000\u01ff\u0201\u0003"+
		"Z-\u0000\u0200\u01fe\u0001\u0000\u0000\u0000\u0201\u0204\u0001\u0000\u0000"+
		"\u0000\u0202\u0200\u0001\u0000\u0000\u0000\u0202\u0203\u0001\u0000\u0000"+
		"\u0000\u0203\u0205\u0001\u0000\u0000\u0000\u0204\u0202\u0001\u0000\u0000"+
		"\u0000\u0205\u0206\u0005\u001b\u0000\u0000\u0206\u0210\u0003Z-\u0000\u0207"+
		"\u0208\u0005U\u0000\u0000\u0208\u0209\u0003Z-\u0000\u0209\u020a\u0005"+
		"\\\u0000\u0000\u020a\u020b\u0003Z-\u0000\u020b\u020c\u0005U\u0000\u0000"+
		"\u020c\u020d\u0003Z-\u0000\u020d\u020e\u0005U\u0000\u0000\u020e\u020f"+
		"\u0005c\u0000\u0000\u020f\u0211\u0001\u0000\u0000\u0000\u0210\u0207\u0001"+
		"\u0000\u0000\u0000\u0210\u0211\u0001\u0000\u0000\u0000\u0211\u0219\u0001"+
		"\u0000\u0000\u0000\u0212\u0213\u0005L\u0000\u0000\u0213\u0214\u0003Z-"+
		"\u0000\u0214\u0215\u0005\\\u0000\u0000\u0215\u0216\u0003Z-\u0000\u0216"+
		"\u0217\u0005U\u0000\u0000\u0217\u0218\u0003Z-\u0000\u0218\u021a\u0001"+
		"\u0000\u0000\u0000\u0219\u0212\u0001\u0000\u0000\u0000\u0219\u021a\u0001"+
		"\u0000\u0000\u0000\u021aG\u0001\u0000\u0000\u0000\u021b\u021c\u0003Z-"+
		"\u0000\u021cI\u0001\u0000\u0000\u0000\u021d\u021e\u0003Z-\u0000\u021e"+
		"K\u0001\u0000\u0000\u0000\u021f\u0222\u0003N\'\u0000\u0220\u0222\u0003"+
		"P(\u0000\u0221\u021f\u0001\u0000\u0000\u0000\u0221\u0220\u0001\u0000\u0000"+
		"\u0000\u0222M\u0001\u0000\u0000\u0000\u0223\u0224\u0003Z-\u0000\u0224"+
		"\u022d\u0005S\u0000\u0000\u0225\u022c\u0005\"\u0000\u0000\u0226\u022c"+
		"\u0005\u0013\u0000\u0000\u0227\u022c\u00059\u0000\u0000\u0228\u022c\u0005"+
		"D\u0000\u0000\u0229\u022a\u0005-\u0000\u0000\u022a\u022c\u0005.\u0000"+
		"\u0000\u022b\u0225\u0001\u0000\u0000\u0000\u022b\u0226\u0001\u0000\u0000"+
		"\u0000\u022b\u0227\u0001\u0000\u0000\u0000\u022b\u0228\u0001\u0000\u0000"+
		"\u0000\u022b\u0229\u0001\u0000\u0000\u0000\u022c\u022f\u0001\u0000\u0000"+
		"\u0000\u022d\u022b\u0001\u0000\u0000\u0000\u022d\u022e\u0001\u0000\u0000"+
		"\u0000\u022eO\u0001\u0000\u0000\u0000\u022f\u022d\u0001\u0000\u0000\u0000"+
		"\u0230\u0233\u0003T*\u0000\u0231\u0233\u0003R)\u0000\u0232\u0230\u0001"+
		"\u0000\u0000\u0000\u0232\u0231\u0001\u0000\u0000\u0000\u0233Q\u0001\u0000"+
		"\u0000\u0000\u0234\u0235\u0003Z-\u0000\u0235\u0236\u0003Z-\u0000\u0236"+
		"\u0237\u00058\u0000\u0000\u0237\u0238\u0005*\u0000\u0000\u0238\u0239\u0003"+
		"Z-\u0000\u0239S\u0001\u0000\u0000\u0000\u023a\u023b\u0003Z-\u0000\u023b"+
		"\u023c\u0003Z-\u0000\u023c\u023d\u00058\u0000\u0000\u023d\u023e\u0005"+
		"V\u0000\u0000\u023e\u023f\u0003V+\u0000\u023f\u0240\u0005X\u0000\u0000"+
		"\u0240\u0241\u0003V+\u0000\u0241\u0243\u0005W\u0000\u0000\u0242\u0244"+
		"\u0005\t\u0000\u0000\u0243\u0242\u0001\u0000\u0000\u0000\u0243\u0244\u0001"+
		"\u0000\u0000\u0000\u0244U\u0001\u0000\u0000\u0000\u0245\u0246\u0007\u0000"+
		"\u0000\u0000\u0246W\u0001\u0000\u0000\u0000\u0247\u0248\u0005_\u0000\u0000"+
		"\u0248Y\u0001\u0000\u0000\u0000\u0249\u024a\u0005c\u0000\u0000\u024a["+
		"\u0001\u0000\u0000\u0000\u024b\u024c\u0005d\u0000\u0000\u024c]\u0001\u0000"+
		"\u0000\u0000\u024d\u0251\u0005e\u0000\u0000\u024e\u0250\u0005e\u0000\u0000"+
		"\u024f\u024e\u0001\u0000\u0000\u0000\u0250\u0253\u0001\u0000\u0000\u0000"+
		"\u0251\u0252\u0001\u0000\u0000\u0000\u0251\u024f\u0001\u0000\u0000\u0000"+
		"\u0252_\u0001\u0000\u0000\u0000\u0253\u0251\u0001\u0000\u0000\u0000\u0254"+
		"\u0255\u0005f\u0000\u0000\u0255a\u0001\u0000\u0000\u0000\u0256\u0257\u0005"+
		"^\u0000\u0000\u0257c\u0001\u0000\u0000\u0000\u0258\u0259\u0005`\u0000"+
		"\u0000\u0259e\u0001\u0000\u0000\u0000+is|\u0084\u008a\u009a\u00a0\u00aa"+
		"\u00b0\u00bc\u00c0\u00c9\u00cc\u00cf\u00d1\u00da\u00e4\u00e8\u00f8\u00fd"+
		"\u0104\u0107\u010a\u0111\u0114\u0119\u0163\u0167\u0172\u017f\u018d\u0196"+
		"\u01df\u01e9\u0202\u0210\u0219\u0221\u022b\u022d\u0232\u0243\u0251";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}